from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, timedelta
import enum
import json

db = SQLAlchemy()

class SessionStatus(enum.Enum):
    ACTIVE = "active"
    TERMINATED = "terminated"
    EXPIRED = "expired"
    SUSPENDED = "suspended"

class SessionType(enum.Enum):
    SSH = "ssh"
    RDP = "rdp"
    WEB = "web"
    DATABASE = "database"
    API = "api"

class PrivilegedSession(db.Model):
    __tablename__ = 'privileged_sessions'
    
    id = db.Column(db.Integer, primary_key=True)
    session_token = db.Column(db.String(255), unique=True, nullable=False, index=True)
    
    # Пользователь и система
    user_id = db.Column(db.Integer, db.ForeignKey('privileged_users.id'), nullable=False)
    target_system = db.Column(db.String(200), nullable=False)
    target_host = db.Column(db.String(255), nullable=False)
    target_port = db.Column(db.Integer)
    
    # Тип и статус сессии
    session_type = db.Column(db.Enum(SessionType), nullable=False)
    status = db.Column(db.Enum(SessionStatus), nullable=False, default=SessionStatus.ACTIVE)
    
    # Временные рамки
    start_time = db.Column(db.DateTime, default=datetime.utcnow)
    end_time = db.Column(db.DateTime)
    max_duration_minutes = db.Column(db.Integer, default=480)  # 8 часов по умолчанию
    idle_timeout_minutes = db.Column(db.Integer, default=30)
    last_activity = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Контекст доступа
    source_ip = db.Column(db.String(45))  # IPv6 поддержка
    user_agent = db.Column(db.String(500))
    justification = db.Column(db.Text)  # Обоснование доступа
    approved_by = db.Column(db.Integer, db.ForeignKey('privileged_users.id'))
    
    # Мониторинг и запись
    recording_enabled = db.Column(db.Boolean, default=True)
    recording_path = db.Column(db.String(500))
    commands_logged = db.Column(db.Integer, default=0)
    
    # Связи
    activities = db.relationship('SessionActivity', backref='session', lazy=True)
    alerts = db.relationship('SessionAlert', backref='session', lazy=True)

    def is_active(self):
        """Проверяет, активна ли сессия"""
        return self.status == SessionStatus.ACTIVE

    def is_expired(self):
        """Проверяет, истекла ли сессия"""
        if self.status in [SessionStatus.EXPIRED, SessionStatus.TERMINATED]:
            return True
        
        # Проверка максимальной продолжительности
        if self.max_duration_minutes:
            max_end_time = self.start_time + timedelta(minutes=self.max_duration_minutes)
            if datetime.utcnow() > max_end_time:
                return True
        
        # Проверка таймаута бездействия
        if self.idle_timeout_minutes and self.last_activity:
            idle_end_time = self.last_activity + timedelta(minutes=self.idle_timeout_minutes)
            if datetime.utcnow() > idle_end_time:
                return True
        
        return False

    def update_activity(self):
        """Обновляет время последней активности"""
        self.last_activity = datetime.utcnow()

    def terminate(self, reason="Manual termination"):
        """Завершает сессию"""
        self.status = SessionStatus.TERMINATED
        self.end_time = datetime.utcnow()
        
        # Логируем завершение
        activity = SessionActivity(
            session_id=self.id,
            activity_type="session_terminated",
            description=reason,
            timestamp=datetime.utcnow()
        )
        db.session.add(activity)

    def suspend(self, reason="Suspicious activity"):
        """Приостанавливает сессию"""
        self.status = SessionStatus.SUSPENDED
        
        # Логируем приостановку
        activity = SessionActivity(
            session_id=self.id,
            activity_type="session_suspended",
            description=reason,
            timestamp=datetime.utcnow()
        )
        db.session.add(activity)

    def get_duration(self):
        """Возвращает продолжительность сессии"""
        end_time = self.end_time or datetime.utcnow()
        return end_time - self.start_time

    def to_dict(self):
        return {
            'id': self.id,
            'session_token': self.session_token,
            'user_id': self.user_id,
            'target_system': self.target_system,
            'target_host': self.target_host,
            'target_port': self.target_port,
            'session_type': self.session_type.value if self.session_type else None,
            'status': self.status.value if self.status else None,
            'start_time': self.start_time.isoformat() if self.start_time else None,
            'end_time': self.end_time.isoformat() if self.end_time else None,
            'max_duration_minutes': self.max_duration_minutes,
            'idle_timeout_minutes': self.idle_timeout_minutes,
            'last_activity': self.last_activity.isoformat() if self.last_activity else None,
            'source_ip': self.source_ip,
            'justification': self.justification,
            'approved_by': self.approved_by,
            'recording_enabled': self.recording_enabled,
            'commands_logged': self.commands_logged,
            'duration_seconds': int(self.get_duration().total_seconds()),
            'is_active': self.is_active(),
            'is_expired': self.is_expired()
        }

    def __repr__(self):
        return f'<PrivilegedSession {self.session_token}>'

class SessionActivity(db.Model):
    __tablename__ = 'session_activities'
    
    id = db.Column(db.Integer, primary_key=True)
    session_id = db.Column(db.Integer, db.ForeignKey('privileged_sessions.id'), nullable=False)
    
    timestamp = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    activity_type = db.Column(db.String(100), nullable=False)  # command, file_access, login, etc.
    description = db.Column(db.Text)
    command = db.Column(db.Text)
    file_path = db.Column(db.String(500))
    
    # Метаданные активности
    risk_score = db.Column(db.Integer, default=0)  # 0-100
    is_anomalous = db.Column(db.Boolean, default=False)
    activity_metadata = db.Column(db.Text)  # JSON данные

    def set_metadata(self, data):
        """Устанавливает метаданные в формате JSON"""
        self.activity_metadata = json.dumps(data) if data else None

    def get_metadata(self):
        """Получает метаданные из JSON"""
        return json.loads(self.activity_metadata) if self.activity_metadata else {}

    def to_dict(self):
        return {
            'id': self.id,
            'session_id': self.session_id,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None,
            'activity_type': self.activity_type,
            'description': self.description,
            'command': self.command,
            'file_path': self.file_path,
            'risk_score': self.risk_score,
            'is_anomalous': self.is_anomalous,
            'metadata': self.get_metadata()
        }

class SessionAlert(db.Model):
    __tablename__ = 'session_alerts'
    
    id = db.Column(db.Integer, primary_key=True)
    session_id = db.Column(db.Integer, db.ForeignKey('privileged_sessions.id'), nullable=False)
    
    alert_type = db.Column(db.String(100), nullable=False)
    severity = db.Column(db.String(20), nullable=False)  # low, medium, high, critical
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    
    triggered_at = db.Column(db.DateTime, default=datetime.utcnow)
    acknowledged = db.Column(db.Boolean, default=False)
    acknowledged_by = db.Column(db.Integer, db.ForeignKey('privileged_users.id'))
    acknowledged_at = db.Column(db.DateTime)
    
    # Действия
    action_taken = db.Column(db.String(100))  # none, suspend, terminate, notify
    
    def acknowledge(self, user_id):
        """Подтверждает получение алерта"""
        self.acknowledged = True
        self.acknowledged_by = user_id
        self.acknowledged_at = datetime.utcnow()

    def to_dict(self):
        return {
            'id': self.id,
            'session_id': self.session_id,
            'alert_type': self.alert_type,
            'severity': self.severity,
            'title': self.title,
            'description': self.description,
            'triggered_at': self.triggered_at.isoformat() if self.triggered_at else None,
            'acknowledged': self.acknowledged,
            'acknowledged_by': self.acknowledged_by,
            'acknowledged_at': self.acknowledged_at.isoformat() if self.acknowledged_at else None,
            'action_taken': self.action_taken
        }

