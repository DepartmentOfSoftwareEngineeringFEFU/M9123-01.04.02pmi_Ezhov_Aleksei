from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, timedelta
from cryptography.fernet import Fernet
import os
import enum

db = SQLAlchemy()

class CredentialType(enum.Enum):
    PASSWORD = "password"
    SSH_KEY = "ssh_key"
    API_KEY = "api_key"
    CERTIFICATE = "certificate"
    TOKEN = "token"

class CredentialStatus(enum.Enum):
    ACTIVE = "active"
    EXPIRED = "expired"
    REVOKED = "revoked"
    PENDING_ROTATION = "pending_rotation"

class PrivilegedCredential(db.Model):
    __tablename__ = 'privileged_credentials'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    
    # Тип учетных данных
    credential_type = db.Column(db.Enum(CredentialType), nullable=False)
    status = db.Column(db.Enum(CredentialStatus), nullable=False, default=CredentialStatus.ACTIVE)
    
    # Целевая система
    target_system = db.Column(db.String(200), nullable=False)
    target_host = db.Column(db.String(255))
    target_port = db.Column(db.Integer)
    target_username = db.Column(db.String(100))
    
    # Зашифрованные учетные данные
    encrypted_credential = db.Column(db.Text, nullable=False)
    encryption_key_id = db.Column(db.String(100))
    
    # Политики ротации
    rotation_enabled = db.Column(db.Boolean, default=True)
    rotation_interval_days = db.Column(db.Integer, default=90)
    last_rotated = db.Column(db.DateTime, default=datetime.utcnow)
    next_rotation = db.Column(db.DateTime)
    
    # Метаданные
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = db.Column(db.Integer, db.ForeignKey('privileged_users.id'))
    
    # Связи
    access_logs = db.relationship('CredentialAccess', backref='credential', lazy=True)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        if self.rotation_enabled and self.rotation_interval_days:
            self.next_rotation = self.last_rotated + timedelta(days=self.rotation_interval_days)

    @staticmethod
    def generate_encryption_key():
        """Генерирует ключ шифрования"""
        return Fernet.generate_key()

    def encrypt_credential(self, credential_data, encryption_key=None):
        """Шифрует учетные данные"""
        if encryption_key is None:
            encryption_key = self.generate_encryption_key()
            self.encryption_key_id = encryption_key.decode()[:20]  # Сохраняем ID ключа
        
        fernet = Fernet(encryption_key)
        self.encrypted_credential = fernet.encrypt(credential_data.encode()).decode()

    def decrypt_credential(self, encryption_key):
        """Расшифровывает учетные данные"""
        try:
            fernet = Fernet(encryption_key)
            return fernet.decrypt(self.encrypted_credential.encode()).decode()
        except Exception as e:
            raise ValueError(f"Failed to decrypt credential: {str(e)}")

    def is_expired(self):
        """Проверяет, истекли ли учетные данные"""
        if self.status == CredentialStatus.EXPIRED:
            return True
        
        if self.next_rotation and datetime.utcnow() > self.next_rotation:
            self.status = CredentialStatus.PENDING_ROTATION
            return True
        
        return False

    def needs_rotation(self):
        """Проверяет, нужна ли ротация"""
        return (self.rotation_enabled and 
                self.next_rotation and 
                datetime.utcnow() >= self.next_rotation)

    def rotate_credential(self, new_credential_data, encryption_key):
        """Выполняет ротацию учетных данных"""
        self.encrypt_credential(new_credential_data, encryption_key)
        self.last_rotated = datetime.utcnow()
        if self.rotation_interval_days:
            self.next_rotation = self.last_rotated + timedelta(days=self.rotation_interval_days)
        self.status = CredentialStatus.ACTIVE

    def to_dict(self, include_sensitive=False):
        data = {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'credential_type': self.credential_type.value if self.credential_type else None,
            'status': self.status.value if self.status else None,
            'target_system': self.target_system,
            'target_host': self.target_host,
            'target_port': self.target_port,
            'target_username': self.target_username,
            'rotation_enabled': self.rotation_enabled,
            'rotation_interval_days': self.rotation_interval_days,
            'last_rotated': self.last_rotated.isoformat() if self.last_rotated else None,
            'next_rotation': self.next_rotation.isoformat() if self.next_rotation else None,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'needs_rotation': self.needs_rotation(),
            'is_expired': self.is_expired()
        }
        
        if include_sensitive:
            data['encryption_key_id'] = self.encryption_key_id
        
        return data

    def __repr__(self):
        return f'<PrivilegedCredential {self.name}>'

class CredentialAccess(db.Model):
    __tablename__ = 'credential_access'
    
    id = db.Column(db.Integer, primary_key=True)
    credential_id = db.Column(db.Integer, db.ForeignKey('privileged_credentials.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('privileged_users.id'), nullable=False)
    session_id = db.Column(db.Integer, db.ForeignKey('privileged_sessions.id'))
    
    access_time = db.Column(db.DateTime, default=datetime.utcnow)
    access_purpose = db.Column(db.String(500))
    approved_by = db.Column(db.Integer, db.ForeignKey('privileged_users.id'))
    
    def to_dict(self):
        return {
            'id': self.id,
            'credential_id': self.credential_id,
            'user_id': self.user_id,
            'session_id': self.session_id,
            'access_time': self.access_time.isoformat() if self.access_time else None,
            'access_purpose': self.access_purpose,
            'approved_by': self.approved_by
        }

