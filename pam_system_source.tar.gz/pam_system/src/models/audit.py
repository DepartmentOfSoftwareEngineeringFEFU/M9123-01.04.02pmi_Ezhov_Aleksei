from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import enum
import json

db = SQLAlchemy()

class AuditEventType(enum.Enum):
    LOGIN = "login"
    LOGOUT = "logout"
    LOGIN_FAILED = "login_failed"
    PASSWORD_CHANGE = "password_change"
    CREDENTIAL_ACCESS = "credential_access"
    PRIVILEGE_ESCALATION = "privilege_escalation"
    SYSTEM_ACCESS = "system_access"
    FILE_ACCESS = "file_access"
    COMMAND_EXECUTION = "command_execution"
    POLICY_VIOLATION = "policy_violation"
    ANOMALY_DETECTED = "anomaly_detected"
    SESSION_START = "session_start"
    SESSION_END = "session_end"
    USER_CREATED = "user_created"
    USER_MODIFIED = "user_modified"
    USER_DELETED = "user_deleted"
    SYSTEM_CONFIGURATION = "system_configuration"

class AuditSeverity(enum.Enum):
    INFO = "info"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class AuditLog(db.Model):
    __tablename__ = 'audit_logs'
    
    id = db.Column(db.Integer, primary_key=True)
    
    # Основная информация о событии
    event_type = db.Column(db.Enum(AuditEventType), nullable=False, index=True)
    severity = db.Column(db.Enum(AuditSeverity), nullable=False, default=AuditSeverity.INFO)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    
    # Пользователь и сессия
    user_id = db.Column(db.Integer, db.ForeignKey('privileged_users.id'), index=True)
    session_id = db.Column(db.Integer, db.ForeignKey('privileged_sessions.id'))
    
    # Детали события
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    
    # Контекст
    source_ip = db.Column(db.String(45), index=True)
    user_agent = db.Column(db.String(500))
    target_system = db.Column(db.String(200))
    target_resource = db.Column(db.String(500))
    
    # Результат и статус
    success = db.Column(db.Boolean, default=True)
    error_message = db.Column(db.Text)
    
    # Дополнительные данные
    event_metadata = db.Column(db.Text)  # JSON данные
    risk_score = db.Column(db.Integer, default=0)  # 0-100
    
    # Корреляция с другими событиями
    correlation_id = db.Column(db.String(100), index=True)
    parent_event_id = db.Column(db.Integer, db.ForeignKey('audit_logs.id'))
    
    # Связи
    child_events = db.relationship('AuditLog', backref=db.backref('parent_event', remote_side=[id]))

    def set_metadata(self, data):
        """Устанавливает метаданные в формате JSON"""
        self.event_metadata = json.dumps(data) if data else None

    def get_metadata(self):
        """Получает метаданные из JSON"""
        return json.loads(self.event_metadata) if self.event_metadata else {}

    def is_security_event(self):
        """Проверяет, является ли событие связанным с безопасностью"""
        security_events = [
            AuditEventType.LOGIN_FAILED,
            AuditEventType.PRIVILEGE_ESCALATION,
            AuditEventType.POLICY_VIOLATION,
            AuditEventType.ANOMALY_DETECTED
        ]
        return self.event_type in security_events or self.severity in [AuditSeverity.HIGH, AuditSeverity.CRITICAL]

    def to_dict(self):
        return {
            'id': self.id,
            'event_type': self.event_type.value if self.event_type else None,
            'severity': self.severity.value if self.severity else None,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None,
            'user_id': self.user_id,
            'session_id': self.session_id,
            'title': self.title,
            'description': self.description,
            'source_ip': self.source_ip,
            'user_agent': self.user_agent,
            'target_system': self.target_system,
            'target_resource': self.target_resource,
            'success': self.success,
            'error_message': self.error_message,
            'metadata': self.get_metadata(),
            'risk_score': self.risk_score,
            'correlation_id': self.correlation_id,
            'parent_event_id': self.parent_event_id,
            'is_security_event': self.is_security_event()
        }

    def __repr__(self):
        return f'<AuditLog {self.event_type.value}: {self.title}>'

class ComplianceReport(db.Model):
    __tablename__ = 'compliance_reports'
    
    id = db.Column(db.Integer, primary_key=True)
    
    # Основная информация
    report_name = db.Column(db.String(200), nullable=False)
    report_type = db.Column(db.String(100), nullable=False)  # daily, weekly, monthly, custom
    compliance_standard = db.Column(db.String(100))  # ISO27001, PCI-DSS, SOX, etc.
    
    # Временной период
    period_start = db.Column(db.DateTime, nullable=False)
    period_end = db.Column(db.DateTime, nullable=False)
    
    # Статус отчета
    generated_at = db.Column(db.DateTime, default=datetime.utcnow)
    generated_by = db.Column(db.Integer, db.ForeignKey('privileged_users.id'))
    status = db.Column(db.String(50), default='completed')  # generating, completed, failed
    
    # Результаты
    total_events = db.Column(db.Integer, default=0)
    security_events = db.Column(db.Integer, default=0)
    policy_violations = db.Column(db.Integer, default=0)
    failed_access_attempts = db.Column(db.Integer, default=0)
    
    # Файлы отчета
    report_file_path = db.Column(db.String(500))
    report_format = db.Column(db.String(20), default='pdf')  # pdf, csv, json
    
    # Дополнительные данные
    summary = db.Column(db.Text)
    recommendations = db.Column(db.Text)

    def to_dict(self):
        return {
            'id': self.id,
            'report_name': self.report_name,
            'report_type': self.report_type,
            'compliance_standard': self.compliance_standard,
            'period_start': self.period_start.isoformat() if self.period_start else None,
            'period_end': self.period_end.isoformat() if self.period_end else None,
            'generated_at': self.generated_at.isoformat() if self.generated_at else None,
            'generated_by': self.generated_by,
            'status': self.status,
            'total_events': self.total_events,
            'security_events': self.security_events,
            'policy_violations': self.policy_violations,
            'failed_access_attempts': self.failed_access_attempts,
            'report_format': self.report_format,
            'summary': self.summary,
            'recommendations': self.recommendations
        }

class AnomalyDetection(db.Model):
    __tablename__ = 'anomaly_detections'
    
    id = db.Column(db.Integer, primary_key=True)
    
    # Связанные объекты
    user_id = db.Column(db.Integer, db.ForeignKey('privileged_users.id'), index=True)
    session_id = db.Column(db.Integer, db.ForeignKey('privileged_sessions.id'))
    
    # Детали аномалии
    anomaly_type = db.Column(db.String(100), nullable=False)  # unusual_time, unusual_location, unusual_command, etc.
    confidence_score = db.Column(db.Float, nullable=False)  # 0.0 - 1.0
    risk_score = db.Column(db.Integer, nullable=False)  # 0-100
    
    # Описание
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    
    # Временные метки
    detected_at = db.Column(db.DateTime, default=datetime.utcnow)
    event_time = db.Column(db.DateTime, nullable=False)
    
    # Статус обработки
    status = db.Column(db.String(50), default='new')  # new, investigating, resolved, false_positive
    investigated_by = db.Column(db.Integer, db.ForeignKey('privileged_users.id'))
    investigated_at = db.Column(db.DateTime)
    resolution_notes = db.Column(db.Text)
    
    # Действия
    action_taken = db.Column(db.String(100))  # none, alert, suspend_session, block_user
    
    # Дополнительные данные
    baseline_data = db.Column(db.Text)  # JSON с базовыми показателями
    anomaly_data = db.Column(db.Text)   # JSON с данными аномалии

    def set_baseline_data(self, data):
        """Устанавливает базовые данные в формате JSON"""
        self.baseline_data = json.dumps(data) if data else None

    def get_baseline_data(self):
        """Получает базовые данные из JSON"""
        return json.loads(self.baseline_data) if self.baseline_data else {}

    def set_anomaly_data(self, data):
        """Устанавливает данные аномалии в формате JSON"""
        self.anomaly_data = json.dumps(data) if data else None

    def get_anomaly_data(self):
        """Получает данные аномалии из JSON"""
        return json.loads(self.anomaly_data) if self.anomaly_data else {}

    def mark_as_resolved(self, user_id, notes=None):
        """Отмечает аномалию как решенную"""
        self.status = 'resolved'
        self.investigated_by = user_id
        self.investigated_at = datetime.utcnow()
        if notes:
            self.resolution_notes = notes

    def mark_as_false_positive(self, user_id, notes=None):
        """Отмечает аномалию как ложное срабатывание"""
        self.status = 'false_positive'
        self.investigated_by = user_id
        self.investigated_at = datetime.utcnow()
        if notes:
            self.resolution_notes = notes

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'session_id': self.session_id,
            'anomaly_type': self.anomaly_type,
            'confidence_score': self.confidence_score,
            'risk_score': self.risk_score,
            'title': self.title,
            'description': self.description,
            'detected_at': self.detected_at.isoformat() if self.detected_at else None,
            'event_time': self.event_time.isoformat() if self.event_time else None,
            'status': self.status,
            'investigated_by': self.investigated_by,
            'investigated_at': self.investigated_at.isoformat() if self.investigated_at else None,
            'resolution_notes': self.resolution_notes,
            'action_taken': self.action_taken,
            'baseline_data': self.get_baseline_data(),
            'anomaly_data': self.get_anomaly_data()
        }

