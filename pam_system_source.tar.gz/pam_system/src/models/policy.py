from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, time
import enum
import json

db = SQLAlchemy()

class PolicyType(enum.Enum):
    ACCESS_CONTROL = "access_control"
    TIME_RESTRICTION = "time_restriction"
    IP_RESTRICTION = "ip_restriction"
    COMMAND_RESTRICTION = "command_restriction"
    APPROVAL_REQUIRED = "approval_required"
    SESSION_RECORDING = "session_recording"
    PASSWORD_POLICY = "password_policy"

class PolicyStatus(enum.Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    DRAFT = "draft"

class PolicyAction(enum.Enum):
    ALLOW = "allow"
    DENY = "deny"
    REQUIRE_APPROVAL = "require_approval"
    LOG_ONLY = "log_only"

class AccessPolicy(db.Model):
    __tablename__ = 'access_policies'
    
    id = db.Column(db.Integer, primary_key=True)
    
    # Основная информация
    name = db.Column(db.String(200), nullable=False, unique=True)
    description = db.Column(db.Text)
    policy_type = db.Column(db.Enum(PolicyType), nullable=False)
    status = db.Column(db.Enum(PolicyStatus), nullable=False, default=PolicyStatus.ACTIVE)
    
    # Приоритет выполнения (чем меньше число, тем выше приоритет)
    priority = db.Column(db.Integer, default=100)
    
    # Действие при срабатывании
    action = db.Column(db.Enum(PolicyAction), nullable=False, default=PolicyAction.ALLOW)
    
    # Условия применения политики
    conditions = db.Column(db.Text)  # JSON с условиями
    
    # Временные ограничения
    time_start = db.Column(db.Time)
    time_end = db.Column(db.Time)
    days_of_week = db.Column(db.String(20))  # "1,2,3,4,5" для пн-пт
    
    # Метаданные
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = db.Column(db.Integer, db.ForeignKey('privileged_users.id'))
    
    # Связи
    violations = db.relationship('PolicyViolation', backref='policy', lazy=True)

    def set_conditions(self, conditions_dict):
        """Устанавливает условия политики в формате JSON"""
        self.conditions = json.dumps(conditions_dict) if conditions_dict else None

    def get_conditions(self):
        """Получает условия политики из JSON"""
        return json.loads(self.conditions) if self.conditions else {}

    def is_applicable_now(self):
        """Проверяет, применима ли политика в текущее время"""
        if self.status != PolicyStatus.ACTIVE:
            return False
        
        now = datetime.now()
        current_time = now.time()
        current_day = now.weekday() + 1  # 1=понедельник, 7=воскресенье
        
        # Проверка времени
        if self.time_start and self.time_end:
            if not (self.time_start <= current_time <= self.time_end):
                return False
        
        # Проверка дней недели
        if self.days_of_week:
            allowed_days = [int(d) for d in self.days_of_week.split(',')]
            if current_day not in allowed_days:
                return False
        
        return True

    def evaluate_conditions(self, context):
        """Оценивает условия политики для данного контекста"""
        conditions = self.get_conditions()
        if not conditions:
            return True
        
        # Проверка IP адреса
        if 'allowed_ips' in conditions:
            user_ip = context.get('source_ip')
            if user_ip and user_ip not in conditions['allowed_ips']:
                return False
        
        # Проверка пользователей
        if 'allowed_users' in conditions:
            user_id = context.get('user_id')
            if user_id and user_id not in conditions['allowed_users']:
                return False
        
        # Проверка ролей
        if 'allowed_roles' in conditions:
            user_role = context.get('user_role')
            if user_role and user_role not in conditions['allowed_roles']:
                return False
        
        # Проверка целевых систем
        if 'allowed_systems' in conditions:
            target_system = context.get('target_system')
            if target_system and target_system not in conditions['allowed_systems']:
                return False
        
        # Проверка команд (для политик ограничения команд)
        if 'blocked_commands' in conditions:
            command = context.get('command', '').lower()
            blocked = conditions['blocked_commands']
            if any(blocked_cmd.lower() in command for blocked_cmd in blocked):
                return False
        
        return True

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'policy_type': self.policy_type.value if self.policy_type else None,
            'status': self.status.value if self.status else None,
            'priority': self.priority,
            'action': self.action.value if self.action else None,
            'conditions': self.get_conditions(),
            'time_start': self.time_start.strftime('%H:%M') if self.time_start else None,
            'time_end': self.time_end.strftime('%H:%M') if self.time_end else None,
            'days_of_week': self.days_of_week,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'is_applicable_now': self.is_applicable_now()
        }

    def __repr__(self):
        return f'<AccessPolicy {self.name}>'

class PolicyViolation(db.Model):
    __tablename__ = 'policy_violations'
    
    id = db.Column(db.Integer, primary_key=True)
    
    # Связанные объекты
    policy_id = db.Column(db.Integer, db.ForeignKey('access_policies.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('privileged_users.id'), nullable=False)
    session_id = db.Column(db.Integer, db.ForeignKey('privileged_sessions.id'))
    
    # Детали нарушения
    violation_time = db.Column(db.DateTime, default=datetime.utcnow)
    violation_type = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    
    # Контекст нарушения
    source_ip = db.Column(db.String(45))
    target_system = db.Column(db.String(200))
    attempted_action = db.Column(db.String(500))
    
    # Результат
    action_taken = db.Column(db.String(100))  # blocked, logged, alerted
    severity = db.Column(db.String(20), default='medium')  # low, medium, high, critical
    
    # Статус обработки
    acknowledged = db.Column(db.Boolean, default=False)
    acknowledged_by = db.Column(db.Integer, db.ForeignKey('privileged_users.id'))
    acknowledged_at = db.Column(db.DateTime)
    resolution_notes = db.Column(db.Text)

    def acknowledge(self, user_id, notes=None):
        """Подтверждает обработку нарушения"""
        self.acknowledged = True
        self.acknowledged_by = user_id
        self.acknowledged_at = datetime.utcnow()
        if notes:
            self.resolution_notes = notes

    def to_dict(self):
        return {
            'id': self.id,
            'policy_id': self.policy_id,
            'user_id': self.user_id,
            'session_id': self.session_id,
            'violation_time': self.violation_time.isoformat() if self.violation_time else None,
            'violation_type': self.violation_type,
            'description': self.description,
            'source_ip': self.source_ip,
            'target_system': self.target_system,
            'attempted_action': self.attempted_action,
            'action_taken': self.action_taken,
            'severity': self.severity,
            'acknowledged': self.acknowledged,
            'acknowledged_by': self.acknowledged_by,
            'acknowledged_at': self.acknowledged_at.isoformat() if self.acknowledged_at else None,
            'resolution_notes': self.resolution_notes
        }

class ApprovalRequest(db.Model):
    __tablename__ = 'approval_requests'
    
    id = db.Column(db.Integer, primary_key=True)
    
    # Запрашивающий пользователь
    requester_id = db.Column(db.Integer, db.ForeignKey('privileged_users.id'), nullable=False)
    
    # Детали запроса
    request_type = db.Column(db.String(100), nullable=False)  # access, credential, privilege_escalation
    target_system = db.Column(db.String(200))
    target_resource = db.Column(db.String(500))
    justification = db.Column(db.Text, nullable=False)
    
    # Временные рамки
    requested_start = db.Column(db.DateTime)
    requested_end = db.Column(db.DateTime)
    duration_minutes = db.Column(db.Integer)
    
    # Статус запроса
    status = db.Column(db.String(50), default='pending')  # pending, approved, rejected, expired
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Утверждение
    approver_id = db.Column(db.Integer, db.ForeignKey('privileged_users.id'))
    approved_at = db.Column(db.DateTime)
    approval_notes = db.Column(db.Text)
    
    # Использование
    used = db.Column(db.Boolean, default=False)
    used_at = db.Column(db.DateTime)
    session_id = db.Column(db.Integer, db.ForeignKey('privileged_sessions.id'))

    def approve(self, approver_id, notes=None):
        """Утверждает запрос"""
        self.status = 'approved'
        self.approver_id = approver_id
        self.approved_at = datetime.utcnow()
        if notes:
            self.approval_notes = notes

    def reject(self, approver_id, notes=None):
        """Отклоняет запрос"""
        self.status = 'rejected'
        self.approver_id = approver_id
        self.approved_at = datetime.utcnow()
        if notes:
            self.approval_notes = notes

    def mark_as_used(self, session_id=None):
        """Отмечает запрос как использованный"""
        self.used = True
        self.used_at = datetime.utcnow()
        if session_id:
            self.session_id = session_id

    def is_expired(self):
        """Проверяет, истек ли запрос"""
        if self.status == 'expired':
            return True
        
        if self.requested_end and datetime.utcnow() > self.requested_end:
            return True
        
        return False

    def to_dict(self):
        return {
            'id': self.id,
            'requester_id': self.requester_id,
            'request_type': self.request_type,
            'target_system': self.target_system,
            'target_resource': self.target_resource,
            'justification': self.justification,
            'requested_start': self.requested_start.isoformat() if self.requested_start else None,
            'requested_end': self.requested_end.isoformat() if self.requested_end else None,
            'duration_minutes': self.duration_minutes,
            'status': self.status,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'approver_id': self.approver_id,
            'approved_at': self.approved_at.isoformat() if self.approved_at else None,
            'approval_notes': self.approval_notes,
            'used': self.used,
            'used_at': self.used_at.isoformat() if self.used_at else None,
            'session_id': self.session_id,
            'is_expired': self.is_expired()
        }

