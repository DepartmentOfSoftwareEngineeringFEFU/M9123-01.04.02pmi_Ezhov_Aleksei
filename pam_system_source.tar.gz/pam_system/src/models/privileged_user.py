from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
import enum

db = SQLAlchemy()

class UserRole(enum.Enum):
    ADMIN = "admin"
    OPERATOR = "operator"
    AUDITOR = "auditor"
    USER = "user"

class UserStatus(enum.Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    SUSPENDED = "suspended"
    LOCKED = "locked"

class PrivilegedUser(db.Model):
    __tablename__ = 'privileged_users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False, index=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    full_name = db.Column(db.String(200), nullable=False)
    department = db.Column(db.String(100))
    role = db.Column(db.Enum(UserRole), nullable=False, default=UserRole.USER)
    status = db.Column(db.Enum(UserStatus), nullable=False, default=UserStatus.ACTIVE)
    
    # Временные ограничения доступа
    access_start_time = db.Column(db.Time)
    access_end_time = db.Column(db.Time)
    
    # Метаданные
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    failed_login_attempts = db.Column(db.Integer, default=0)
    
    # Связи (будут настроены после импорта всех моделей)
    # sessions = db.relationship('PrivilegedSession', backref='user', lazy=True)
    # audit_logs = db.relationship('AuditLog', backref='user', lazy=True)

    def set_password(self, password):
        """Устанавливает хэш пароля"""
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        """Проверяет пароль"""
        return check_password_hash(self.password_hash, password)

    def is_active(self):
        """Проверяет, активен ли пользователь"""
        return self.status == UserStatus.ACTIVE

    def can_access_now(self):
        """Проверяет, может ли пользователь получить доступ в текущее время"""
        if not self.is_active():
            return False
        
        if self.access_start_time and self.access_end_time:
            current_time = datetime.now().time()
            return self.access_start_time <= current_time <= self.access_end_time
        
        return True

    def increment_failed_login(self):
        """Увеличивает счетчик неудачных попыток входа"""
        self.failed_login_attempts += 1
        if self.failed_login_attempts >= 5:
            self.status = UserStatus.LOCKED

    def reset_failed_login(self):
        """Сбрасывает счетчик неудачных попыток входа"""
        self.failed_login_attempts = 0

    def to_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'email': self.email,
            'full_name': self.full_name,
            'department': self.department,
            'role': self.role.value if self.role else None,
            'status': self.status.value if self.status else None,
            'access_start_time': self.access_start_time.strftime('%H:%M') if self.access_start_time else None,
            'access_end_time': self.access_end_time.strftime('%H:%M') if self.access_end_time else None,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'last_login': self.last_login.isoformat() if self.last_login else None,
            'failed_login_attempts': self.failed_login_attempts
        }

    def __repr__(self):
        return f'<PrivilegedUser {self.username}>'

