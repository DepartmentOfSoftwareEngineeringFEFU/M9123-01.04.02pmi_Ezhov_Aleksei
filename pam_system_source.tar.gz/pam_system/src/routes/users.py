from flask import Blueprint, request, jsonify, session
from datetime import datetime, time
from src.models.privileged_user import PrivilegedUser, UserRole, UserStatus, db
from src.models.audit import AuditLog, AuditEventType, AuditSeverity

users_bp = Blueprint('users', __name__)

def require_auth():
    """Проверка аутентификации"""
    user_id = session.get('user_id')
    if not user_id:
        return None
    return PrivilegedUser.query.get(user_id)

def require_admin():
    """Проверка прав администратора"""
    user = require_auth()
    if not user or user.role != UserRole.ADMIN:
        return None
    return user

def log_audit_event(event_type, title, description, user_id=None, success=True, severity=AuditSeverity.INFO):
    """Логирует событие аудита"""
    audit_log = AuditLog(
        event_type=event_type,
        title=title,
        description=description,
        user_id=user_id,
        success=success,
        severity=severity,
        source_ip=request.remote_addr,
        user_agent=request.headers.get('User-Agent', '')
    )
    db.session.add(audit_log)
    db.session.commit()

@users_bp.route('/', methods=['GET'])
def get_users():
    """Получение списка пользователей"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        # Только администраторы и аудиторы могут видеть всех пользователей
        if current_user.role not in [UserRole.ADMIN, UserRole.AUDITOR]:
            return jsonify({'error': 'Insufficient privileges'}), 403
        
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        search = request.args.get('search', '')
        
        query = PrivilegedUser.query
        
        if search:
            query = query.filter(
                (PrivilegedUser.username.contains(search)) |
                (PrivilegedUser.full_name.contains(search)) |
                (PrivilegedUser.email.contains(search))
            )
        
        users = query.paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        return jsonify({
            'users': [user.to_dict() for user in users.items],
            'total': users.total,
            'pages': users.pages,
            'current_page': page
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@users_bp.route('/<int:user_id>', methods=['GET'])
def get_user(user_id):
    """Получение информации о пользователе"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        # Пользователи могут видеть только свою информацию, админы и аудиторы - всех
        if current_user.id != user_id and current_user.role not in [UserRole.ADMIN, UserRole.AUDITOR]:
            return jsonify({'error': 'Insufficient privileges'}), 403
        
        user = PrivilegedUser.query.get_or_404(user_id)
        return jsonify(user.to_dict()), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@users_bp.route('/', methods=['POST'])
def create_user():
    """Создание нового пользователя"""
    try:
        current_user = require_admin()
        if not current_user:
            return jsonify({'error': 'Admin privileges required'}), 403
        
        data = request.get_json()
        
        # Проверка обязательных полей
        required_fields = ['username', 'email', 'full_name', 'password']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        # Проверка уникальности
        if PrivilegedUser.query.filter_by(username=data['username']).first():
            return jsonify({'error': 'Username already exists'}), 400
        
        if PrivilegedUser.query.filter_by(email=data['email']).first():
            return jsonify({'error': 'Email already exists'}), 400
        
        # Создание пользователя
        user = PrivilegedUser(
            username=data['username'],
            email=data['email'],
            full_name=data['full_name'],
            department=data.get('department'),
            role=UserRole(data.get('role', 'user')),
            status=UserStatus(data.get('status', 'active'))
        )
        
        user.set_password(data['password'])
        
        # Установка временных ограничений
        if data.get('access_start_time'):
            user.access_start_time = datetime.strptime(data['access_start_time'], '%H:%M').time()
        if data.get('access_end_time'):
            user.access_end_time = datetime.strptime(data['access_end_time'], '%H:%M').time()
        
        db.session.add(user)
        db.session.commit()
        
        log_audit_event(
            AuditEventType.USER_CREATED,
            "Создан новый пользователь",
            f"Администратор {current_user.username} создал пользователя {user.username}",
            user_id=current_user.id,
            severity=AuditSeverity.INFO
        )
        
        return jsonify(user.to_dict()), 201
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@users_bp.route('/<int:user_id>', methods=['PUT'])
def update_user(user_id):
    """Обновление информации о пользователе"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        user = PrivilegedUser.query.get_or_404(user_id)
        
        # Пользователи могут редактировать только свои данные, админы - всех
        if current_user.id != user_id and current_user.role != UserRole.ADMIN:
            return jsonify({'error': 'Insufficient privileges'}), 403
        
        data = request.get_json()
        
        # Обновление полей
        if 'full_name' in data:
            user.full_name = data['full_name']
        if 'email' in data and current_user.role == UserRole.ADMIN:
            # Проверка уникальности email
            existing = PrivilegedUser.query.filter_by(email=data['email']).first()
            if existing and existing.id != user_id:
                return jsonify({'error': 'Email already exists'}), 400
            user.email = data['email']
        if 'department' in data:
            user.department = data['department']
        
        # Только админы могут изменять роль и статус
        if current_user.role == UserRole.ADMIN:
            if 'role' in data:
                user.role = UserRole(data['role'])
            if 'status' in data:
                user.status = UserStatus(data['status'])
            if 'access_start_time' in data:
                user.access_start_time = datetime.strptime(data['access_start_time'], '%H:%M').time() if data['access_start_time'] else None
            if 'access_end_time' in data:
                user.access_end_time = datetime.strptime(data['access_end_time'], '%H:%M').time() if data['access_end_time'] else None
        
        user.updated_at = datetime.utcnow()
        db.session.commit()
        
        log_audit_event(
            AuditEventType.USER_MODIFIED,
            "Обновлена информация о пользователе",
            f"Пользователь {user.username} был обновлен",
            user_id=current_user.id,
            severity=AuditSeverity.INFO
        )
        
        return jsonify(user.to_dict()), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@users_bp.route('/<int:user_id>', methods=['DELETE'])
def delete_user(user_id):
    """Удаление пользователя"""
    try:
        current_user = require_admin()
        if not current_user:
            return jsonify({'error': 'Admin privileges required'}), 403
        
        user = PrivilegedUser.query.get_or_404(user_id)
        
        # Нельзя удалить самого себя
        if user.id == current_user.id:
            return jsonify({'error': 'Cannot delete yourself'}), 400
        
        username = user.username
        db.session.delete(user)
        db.session.commit()
        
        log_audit_event(
            AuditEventType.USER_DELETED,
            "Удален пользователь",
            f"Администратор {current_user.username} удалил пользователя {username}",
            user_id=current_user.id,
            severity=AuditSeverity.MEDIUM
        )
        
        return jsonify({'message': 'User deleted successfully'}), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@users_bp.route('/<int:user_id>/reset-password', methods=['POST'])
def reset_user_password(user_id):
    """Сброс пароля пользователя"""
    try:
        current_user = require_admin()
        if not current_user:
            return jsonify({'error': 'Admin privileges required'}), 403
        
        user = PrivilegedUser.query.get_or_404(user_id)
        data = request.get_json()
        
        new_password = data.get('new_password')
        if not new_password:
            return jsonify({'error': 'New password is required'}), 400
        
        user.set_password(new_password)
        user.failed_login_attempts = 0
        if user.status == UserStatus.LOCKED:
            user.status = UserStatus.ACTIVE
        
        db.session.commit()
        
        log_audit_event(
            AuditEventType.PASSWORD_CHANGE,
            "Сброс пароля администратором",
            f"Администратор {current_user.username} сбросил пароль пользователя {user.username}",
            user_id=current_user.id,
            severity=AuditSeverity.MEDIUM
        )
        
        return jsonify({'message': 'Password reset successfully'}), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@users_bp.route('/<int:user_id>/unlock', methods=['POST'])
def unlock_user(user_id):
    """Разблокировка пользователя"""
    try:
        current_user = require_admin()
        if not current_user:
            return jsonify({'error': 'Admin privileges required'}), 403
        
        user = PrivilegedUser.query.get_or_404(user_id)
        
        user.failed_login_attempts = 0
        user.status = UserStatus.ACTIVE
        db.session.commit()
        
        log_audit_event(
            AuditEventType.USER_MODIFIED,
            "Разблокировка пользователя",
            f"Администратор {current_user.username} разблокировал пользователя {user.username}",
            user_id=current_user.id,
            severity=AuditSeverity.INFO
        )
        
        return jsonify({'message': 'User unlocked successfully'}), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

