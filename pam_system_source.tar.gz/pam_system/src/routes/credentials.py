from flask import Blueprint, request, jsonify, session
from datetime import datetime, timedelta
from src.models.privileged_user import PrivilegedUser, UserRole
from src.models.credential import PrivilegedCredential, CredentialAccess, CredentialType, CredentialStatus, db
from src.models.audit import AuditLog, AuditEventType, AuditSeverity
from cryptography.fernet import Fernet
import os

credentials_bp = Blueprint('credentials', __name__)

# Ключ шифрования (в реальной системе должен храниться в безопасном месте)
ENCRYPTION_KEY = os.environ.get('PAM_ENCRYPTION_KEY', Fernet.generate_key())

def require_auth():
    """Проверка аутентификации"""
    user_id = session.get('user_id')
    if not user_id:
        return None
    return PrivilegedUser.query.get(user_id)

def log_audit_event(event_type, title, description, user_id=None, success=True, severity=AuditSeverity.INFO):
    """Логирует событие аудита"""
    audit_log = AuditLog(
        event_type=event_type,
        title=title,
        description=description,
        user_id=user_id,
        success=success,
        severity=severity,
        source_ip=request.remote_addr,
        user_agent=request.headers.get('User-Agent', '')
    )
    db.session.add(audit_log)
    db.session.commit()

@credentials_bp.route('/', methods=['GET'])
def get_credentials():
    """Получение списка учетных данных"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        # Только админы и операторы могут видеть учетные данные
        if current_user.role not in [UserRole.ADMIN, UserRole.OPERATOR]:
            return jsonify({'error': 'Insufficient privileges'}), 403
        
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        search = request.args.get('search', '')
        credential_type = request.args.get('type', '')
        status = request.args.get('status', '')
        
        query = PrivilegedCredential.query
        
        if search:
            query = query.filter(
                (PrivilegedCredential.name.contains(search)) |
                (PrivilegedCredential.target_system.contains(search)) |
                (PrivilegedCredential.target_host.contains(search))
            )
        
        if credential_type:
            query = query.filter(PrivilegedCredential.credential_type == CredentialType(credential_type))
        
        if status:
            query = query.filter(PrivilegedCredential.status == CredentialStatus(status))
        
        credentials = query.paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        return jsonify({
            'credentials': [cred.to_dict() for cred in credentials.items],
            'total': credentials.total,
            'pages': credentials.pages,
            'current_page': page
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@credentials_bp.route('/<int:credential_id>', methods=['GET'])
def get_credential(credential_id):
    """Получение информации об учетных данных"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        if current_user.role not in [UserRole.ADMIN, UserRole.OPERATOR]:
            return jsonify({'error': 'Insufficient privileges'}), 403
        
        credential = PrivilegedCredential.query.get_or_404(credential_id)
        
        # Логируем просмотр учетных данных
        log_audit_event(
            AuditEventType.CREDENTIAL_ACCESS,
            "Просмотр учетных данных",
            f"Пользователь {current_user.username} просмотрел учетные данные {credential.name}",
            user_id=current_user.id,
            severity=AuditSeverity.INFO
        )
        
        return jsonify(credential.to_dict(include_sensitive=current_user.role == UserRole.ADMIN)), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@credentials_bp.route('/', methods=['POST'])
def create_credential():
    """Создание новых учетных данных"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        if current_user.role != UserRole.ADMIN:
            return jsonify({'error': 'Admin privileges required'}), 403
        
        data = request.get_json()
        
        # Проверка обязательных полей
        required_fields = ['name', 'credential_type', 'target_system', 'credential_data']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        # Проверка уникальности имени
        if PrivilegedCredential.query.filter_by(name=data['name']).first():
            return jsonify({'error': 'Credential name already exists'}), 400
        
        # Создание учетных данных
        credential = PrivilegedCredential(
            name=data['name'],
            description=data.get('description'),
            credential_type=CredentialType(data['credential_type']),
            target_system=data['target_system'],
            target_host=data.get('target_host'),
            target_port=data.get('target_port'),
            target_username=data.get('target_username'),
            rotation_enabled=data.get('rotation_enabled', True),
            rotation_interval_days=data.get('rotation_interval_days', 90),
            created_by=current_user.id
        )
        
        # Шифрование учетных данных
        credential.encrypt_credential(data['credential_data'], ENCRYPTION_KEY)
        
        db.session.add(credential)
        db.session.commit()
        
        log_audit_event(
            AuditEventType.CREDENTIAL_ACCESS,
            "Созданы новые учетные данные",
            f"Администратор {current_user.username} создал учетные данные {credential.name}",
            user_id=current_user.id,
            severity=AuditSeverity.INFO
        )
        
        return jsonify(credential.to_dict()), 201
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@credentials_bp.route('/<int:credential_id>', methods=['PUT'])
def update_credential(credential_id):
    """Обновление учетных данных"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        if current_user.role != UserRole.ADMIN:
            return jsonify({'error': 'Admin privileges required'}), 403
        
        credential = PrivilegedCredential.query.get_or_404(credential_id)
        data = request.get_json()
        
        # Обновление полей
        if 'name' in data:
            # Проверка уникальности имени
            existing = PrivilegedCredential.query.filter_by(name=data['name']).first()
            if existing and existing.id != credential_id:
                return jsonify({'error': 'Credential name already exists'}), 400
            credential.name = data['name']
        
        if 'description' in data:
            credential.description = data['description']
        if 'target_host' in data:
            credential.target_host = data['target_host']
        if 'target_port' in data:
            credential.target_port = data['target_port']
        if 'target_username' in data:
            credential.target_username = data['target_username']
        if 'rotation_enabled' in data:
            credential.rotation_enabled = data['rotation_enabled']
        if 'rotation_interval_days' in data:
            credential.rotation_interval_days = data['rotation_interval_days']
        
        # Обновление учетных данных
        if 'credential_data' in data:
            credential.encrypt_credential(data['credential_data'], ENCRYPTION_KEY)
        
        credential.updated_at = datetime.utcnow()
        db.session.commit()
        
        log_audit_event(
            AuditEventType.CREDENTIAL_ACCESS,
            "Обновлены учетные данные",
            f"Администратор {current_user.username} обновил учетные данные {credential.name}",
            user_id=current_user.id,
            severity=AuditSeverity.MEDIUM
        )
        
        return jsonify(credential.to_dict()), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@credentials_bp.route('/<int:credential_id>', methods=['DELETE'])
def delete_credential(credential_id):
    """Удаление учетных данных"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        if current_user.role != UserRole.ADMIN:
            return jsonify({'error': 'Admin privileges required'}), 403
        
        credential = PrivilegedCredential.query.get_or_404(credential_id)
        credential_name = credential.name
        
        db.session.delete(credential)
        db.session.commit()
        
        log_audit_event(
            AuditEventType.CREDENTIAL_ACCESS,
            "Удалены учетные данные",
            f"Администратор {current_user.username} удалил учетные данные {credential_name}",
            user_id=current_user.id,
            severity=AuditSeverity.HIGH
        )
        
        return jsonify({'message': 'Credential deleted successfully'}), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@credentials_bp.route('/<int:credential_id>/access', methods=['POST'])
def access_credential(credential_id):
    """Доступ к учетным данным"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        if current_user.role not in [UserRole.ADMIN, UserRole.OPERATOR]:
            return jsonify({'error': 'Insufficient privileges'}), 403
        
        credential = PrivilegedCredential.query.get_or_404(credential_id)
        data = request.get_json()
        
        # Проверка статуса учетных данных
        if credential.is_expired():
            return jsonify({'error': 'Credential is expired or needs rotation'}), 400
        
        # Расшифровка учетных данных
        try:
            decrypted_data = credential.decrypt_credential(ENCRYPTION_KEY)
        except Exception as e:
            log_audit_event(
                AuditEventType.CREDENTIAL_ACCESS,
                "Ошибка расшифровки учетных данных",
                f"Не удалось расшифровать учетные данные {credential.name}: {str(e)}",
                user_id=current_user.id,
                success=False,
                severity=AuditSeverity.HIGH
            )
            return jsonify({'error': 'Failed to decrypt credential'}), 500
        
        # Логирование доступа
        access_log = CredentialAccess(
            credential_id=credential_id,
            user_id=current_user.id,
            access_purpose=data.get('purpose', 'Manual access')
        )
        db.session.add(access_log)
        db.session.commit()
        
        log_audit_event(
            AuditEventType.CREDENTIAL_ACCESS,
            "Доступ к учетным данным",
            f"Пользователь {current_user.username} получил доступ к учетным данным {credential.name}",
            user_id=current_user.id,
            severity=AuditSeverity.MEDIUM
        )
        
        return jsonify({
            'credential_data': decrypted_data,
            'target_system': credential.target_system,
            'target_host': credential.target_host,
            'target_port': credential.target_port,
            'target_username': credential.target_username
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@credentials_bp.route('/<int:credential_id>/rotate', methods=['POST'])
def rotate_credential(credential_id):
    """Ротация учетных данных"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        if current_user.role != UserRole.ADMIN:
            return jsonify({'error': 'Admin privileges required'}), 403
        
        credential = PrivilegedCredential.query.get_or_404(credential_id)
        data = request.get_json()
        
        new_credential_data = data.get('new_credential_data')
        if not new_credential_data:
            return jsonify({'error': 'New credential data is required'}), 400
        
        # Выполнение ротации
        credential.rotate_credential(new_credential_data, ENCRYPTION_KEY)
        db.session.commit()
        
        log_audit_event(
            AuditEventType.CREDENTIAL_ACCESS,
            "Ротация учетных данных",
            f"Администратор {current_user.username} выполнил ротацию учетных данных {credential.name}",
            user_id=current_user.id,
            severity=AuditSeverity.MEDIUM
        )
        
        return jsonify({'message': 'Credential rotated successfully'}), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@credentials_bp.route('/expiring', methods=['GET'])
def get_expiring_credentials():
    """Получение учетных данных, требующих ротации"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        if current_user.role not in [UserRole.ADMIN, UserRole.OPERATOR]:
            return jsonify({'error': 'Insufficient privileges'}), 403
        
        # Учетные данные, которые истекают в течение 7 дней
        warning_date = datetime.utcnow() + timedelta(days=7)
        
        expiring_credentials = PrivilegedCredential.query.filter(
            PrivilegedCredential.next_rotation <= warning_date,
            PrivilegedCredential.rotation_enabled == True,
            PrivilegedCredential.status == CredentialStatus.ACTIVE
        ).all()
        
        return jsonify([cred.to_dict() for cred in expiring_credentials]), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

