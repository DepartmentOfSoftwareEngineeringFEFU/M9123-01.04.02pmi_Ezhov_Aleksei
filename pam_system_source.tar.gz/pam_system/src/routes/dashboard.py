from flask import Blueprint, request, jsonify, session
from datetime import datetime, timedelta
from src.models.privileged_user import PrivilegedUser, UserRole, UserStatus
from src.models.session import PrivilegedSession, SessionStatus
from src.models.credential import PrivilegedCredential, CredentialStatus
from src.models.audit import AuditLog, AuditEventType, AuditSeverity, AnomalyDetection
from src.models.policy import PolicyViolation, ApprovalRequest
from sqlalchemy import func, and_, desc
from src.models.privileged_user import db

dashboard_bp = Blueprint('dashboard', __name__)

def require_auth():
    """Проверка аутентификации"""
    user_id = session.get('user_id')
    if not user_id:
        return None
    return PrivilegedUser.query.get(user_id)

@dashboard_bp.route('/overview', methods=['GET'])
def get_dashboard_overview():
    """Получение общего обзора системы"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        # Период для статистики (по умолчанию последние 24 часа)
        hours = request.args.get('hours', 24, type=int)
        start_time = datetime.utcnow() - timedelta(hours=hours)
        
        # Общая статистика пользователей
        total_users = PrivilegedUser.query.count()
        active_users = PrivilegedUser.query.filter_by(status=UserStatus.ACTIVE).count()
        locked_users = PrivilegedUser.query.filter_by(status=UserStatus.LOCKED).count()
        
        # Статистика сессий
        total_sessions = PrivilegedSession.query.filter(PrivilegedSession.start_time >= start_time).count()
        active_sessions = PrivilegedSession.query.filter_by(status=SessionStatus.ACTIVE).count()
        
        # Статистика учетных данных
        total_credentials = PrivilegedCredential.query.count()
        expiring_credentials = PrivilegedCredential.query.filter(
            PrivilegedCredential.next_rotation <= datetime.utcnow() + timedelta(days=7),
            PrivilegedCredential.rotation_enabled == True,
            PrivilegedCredential.status == CredentialStatus.ACTIVE
        ).count()
        
        # События безопасности
        security_events = AuditLog.query.filter(
            AuditLog.timestamp >= start_time,
            AuditLog.severity.in_([AuditSeverity.HIGH, AuditSeverity.CRITICAL])
        ).count()
        
        failed_logins = AuditLog.query.filter(
            AuditLog.timestamp >= start_time,
            AuditLog.event_type == AuditEventType.LOGIN_FAILED
        ).count()
        
        # Нарушения политик
        policy_violations = PolicyViolation.query.filter(
            PolicyViolation.violation_time >= start_time
        ).count()
        
        unacknowledged_violations = PolicyViolation.query.filter(
            PolicyViolation.acknowledged == False
        ).count()
        
        # Аномалии
        new_anomalies = AnomalyDetection.query.filter(
            AnomalyDetection.detected_at >= start_time,
            AnomalyDetection.status == 'new'
        ).count()
        
        # Запросы на утверждение
        pending_approvals = ApprovalRequest.query.filter_by(status='pending').count()
        
        return jsonify({
            'period_hours': hours,
            'users': {
                'total': total_users,
                'active': active_users,
                'locked': locked_users
            },
            'sessions': {
                'total_recent': total_sessions,
                'active': active_sessions
            },
            'credentials': {
                'total': total_credentials,
                'expiring_soon': expiring_credentials
            },
            'security': {
                'security_events': security_events,
                'failed_logins': failed_logins,
                'policy_violations': policy_violations,
                'unacknowledged_violations': unacknowledged_violations,
                'new_anomalies': new_anomalies
            },
            'approvals': {
                'pending': pending_approvals
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@dashboard_bp.route('/activity-timeline', methods=['GET'])
def get_activity_timeline():
    """Получение временной шкалы активности"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        # Период для анализа (по умолчанию последние 7 дней)
        days = request.args.get('days', 7, type=int)
        start_date = datetime.utcnow() - timedelta(days=days)
        
        # Группировка событий по дням
        daily_activity = db.session.query(
            func.date(AuditLog.timestamp).label('date'),
            AuditLog.event_type,
            func.count(AuditLog.id).label('count')
        ).filter(
            AuditLog.timestamp >= start_date
        ).group_by(
            func.date(AuditLog.timestamp),
            AuditLog.event_type
        ).order_by(func.date(AuditLog.timestamp)).all()
        
        # Группировка сессий по дням
        daily_sessions = db.session.query(
            func.date(PrivilegedSession.start_time).label('date'),
            func.count(PrivilegedSession.id).label('count')
        ).filter(
            PrivilegedSession.start_time >= start_date
        ).group_by(func.date(PrivilegedSession.start_time)).all()
        
        # Форматирование данных
        timeline_data = {}
        
        # Добавление событий аудита
        for activity in daily_activity:
            date_str = activity.date.isoformat()
            if date_str not in timeline_data:
                timeline_data[date_str] = {'events': {}, 'sessions': 0}
            
            event_type = activity.event_type.value
            timeline_data[date_str]['events'][event_type] = activity.count
        
        # Добавление сессий
        for session_data in daily_sessions:
            date_str = session_data.date.isoformat()
            if date_str not in timeline_data:
                timeline_data[date_str] = {'events': {}, 'sessions': 0}
            timeline_data[date_str]['sessions'] = session_data.count
        
        return jsonify({
            'period_days': days,
            'timeline': timeline_data
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@dashboard_bp.route('/top-users', methods=['GET'])
def get_top_users():
    """Получение наиболее активных пользователей"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        if current_user.role not in [UserRole.ADMIN, UserRole.AUDITOR]:
            return jsonify({'error': 'Insufficient privileges'}), 403
        
        # Период для анализа
        days = request.args.get('days', 7, type=int)
        start_date = datetime.utcnow() - timedelta(days=days)
        
        # Топ пользователей по количеству событий
        top_users_events = db.session.query(
            AuditLog.user_id,
            func.count(AuditLog.id).label('event_count')
        ).filter(
            AuditLog.timestamp >= start_date,
            AuditLog.user_id.isnot(None)
        ).group_by(AuditLog.user_id).order_by(desc('event_count')).limit(10).all()
        
        # Топ пользователей по количеству сессий
        top_users_sessions = db.session.query(
            PrivilegedSession.user_id,
            func.count(PrivilegedSession.id).label('session_count')
        ).filter(
            PrivilegedSession.start_time >= start_date
        ).group_by(PrivilegedSession.user_id).order_by(desc('session_count')).limit(10).all()
        
        # Получение информации о пользователях
        user_ids = set([u[0] for u in top_users_events] + [u[0] for u in top_users_sessions])
        users_info = {u.id: u.to_dict() for u in PrivilegedUser.query.filter(PrivilegedUser.id.in_(user_ids)).all()}
        
        # Форматирование результатов
        top_events = []
        for user_id, count in top_users_events:
            if user_id in users_info:
                top_events.append({
                    'user': users_info[user_id],
                    'event_count': count
                })
        
        top_sessions = []
        for user_id, count in top_users_sessions:
            if user_id in users_info:
                top_sessions.append({
                    'user': users_info[user_id],
                    'session_count': count
                })
        
        return jsonify({
            'period_days': days,
            'top_by_events': top_events,
            'top_by_sessions': top_sessions
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@dashboard_bp.route('/security-alerts', methods=['GET'])
def get_security_alerts():
    """Получение последних алертов безопасности"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        limit = request.args.get('limit', 20, type=int)
        
        # Последние события высокой важности
        high_severity_events = AuditLog.query.filter(
            AuditLog.severity.in_([AuditSeverity.HIGH, AuditSeverity.CRITICAL])
        ).order_by(AuditLog.timestamp.desc()).limit(limit).all()
        
        # Неподтвержденные нарушения политик
        unacknowledged_violations = PolicyViolation.query.filter_by(
            acknowledged=False
        ).order_by(PolicyViolation.violation_time.desc()).limit(limit).all()
        
        # Новые аномалии
        new_anomalies = AnomalyDetection.query.filter_by(
            status='new'
        ).order_by(AnomalyDetection.detected_at.desc()).limit(limit).all()
        
        return jsonify({
            'high_severity_events': [event.to_dict() for event in high_severity_events],
            'unacknowledged_violations': [violation.to_dict() for violation in unacknowledged_violations],
            'new_anomalies': [anomaly.to_dict() for anomaly in new_anomalies]
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@dashboard_bp.route('/system-health', methods=['GET'])
def get_system_health():
    """Получение информации о состоянии системы"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        if current_user.role not in [UserRole.ADMIN, UserRole.AUDITOR]:
            return jsonify({'error': 'Insufficient privileges'}), 403
        
        # Проверка состояния различных компонентов системы
        
        # Состояние базы данных
        try:
            db.session.execute('SELECT 1')
            database_status = 'healthy'
        except Exception:
            database_status = 'error'
        
        # Статистика ошибок за последний час
        last_hour = datetime.utcnow() - timedelta(hours=1)
        error_count = AuditLog.query.filter(
            AuditLog.timestamp >= last_hour,
            AuditLog.success == False
        ).count()
        
        # Проверка истекающих учетных данных
        expiring_soon = PrivilegedCredential.query.filter(
            PrivilegedCredential.next_rotation <= datetime.utcnow() + timedelta(days=1),
            PrivilegedCredential.rotation_enabled == True,
            PrivilegedCredential.status == CredentialStatus.ACTIVE
        ).count()
        
        # Проверка заблокированных пользователей
        locked_users_count = PrivilegedUser.query.filter_by(status=UserStatus.LOCKED).count()
        
        # Проверка долгих активных сессий (более 8 часов)
        long_sessions = PrivilegedSession.query.filter(
            PrivilegedSession.status == SessionStatus.ACTIVE,
            PrivilegedSession.start_time <= datetime.utcnow() - timedelta(hours=8)
        ).count()
        
        # Определение общего состояния системы
        health_score = 100
        issues = []
        
        if database_status != 'healthy':
            health_score -= 50
            issues.append('Database connection issues')
        
        if error_count > 10:
            health_score -= 20
            issues.append(f'High error rate: {error_count} errors in last hour')
        
        if expiring_soon > 0:
            health_score -= 10
            issues.append(f'{expiring_soon} credentials expiring within 24 hours')
        
        if locked_users_count > 0:
            health_score -= 5
            issues.append(f'{locked_users_count} users are locked')
        
        if long_sessions > 0:
            health_score -= 10
            issues.append(f'{long_sessions} sessions running for more than 8 hours')
        
        overall_status = 'healthy' if health_score >= 80 else 'warning' if health_score >= 60 else 'critical'
        
        return jsonify({
            'overall_status': overall_status,
            'health_score': max(0, health_score),
            'components': {
                'database': database_status,
                'error_rate': 'normal' if error_count <= 5 else 'high',
                'credentials': 'ok' if expiring_soon == 0 else 'warning',
                'users': 'ok' if locked_users_count == 0 else 'warning',
                'sessions': 'ok' if long_sessions == 0 else 'warning'
            },
            'issues': issues,
            'metrics': {
                'errors_last_hour': error_count,
                'expiring_credentials': expiring_soon,
                'locked_users': locked_users_count,
                'long_sessions': long_sessions
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@dashboard_bp.route('/recent-activity', methods=['GET'])
def get_recent_activity():
    """Получение последней активности пользователя"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        limit = request.args.get('limit', 10, type=int)
        
        # Последние события текущего пользователя
        recent_events = AuditLog.query.filter_by(user_id=current_user.id)\
            .order_by(AuditLog.timestamp.desc()).limit(limit).all()
        
        # Последние сессии текущего пользователя
        recent_sessions = PrivilegedSession.query.filter_by(user_id=current_user.id)\
            .order_by(PrivilegedSession.start_time.desc()).limit(limit).all()
        
        return jsonify({
            'recent_events': [event.to_dict() for event in recent_events],
            'recent_sessions': [session.to_dict() for session in recent_sessions]
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

