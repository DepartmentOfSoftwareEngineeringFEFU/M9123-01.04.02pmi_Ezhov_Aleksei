from flask import Blueprint, request, jsonify, session
from datetime import datetime
from src.models.privileged_user import PrivilegedUser, UserStatus, db
from src.models.audit import AuditLog, AuditEventType, AuditSeverity
import uuid

auth_bp = Blueprint('auth', __name__)

def log_audit_event(event_type, title, description, user_id=None, success=True, severity=AuditSeverity.INFO):
    """Логирует событие аудита"""
    audit_log = AuditLog(
        event_type=event_type,
        title=title,
        description=description,
        user_id=user_id,
        success=success,
        severity=severity,
        source_ip=request.remote_addr,
        user_agent=request.headers.get('User-Agent', '')
    )
    db.session.add(audit_log)
    db.session.commit()

@auth_bp.route('/login', methods=['POST'])
def login():
    """Аутентификация пользователя"""
    try:
        data = request.get_json()
        username = data.get('username')
        password = data.get('password')
        
        if not username or not password:
            log_audit_event(
                AuditEventType.LOGIN_FAILED,
                "Неудачная попытка входа",
                f"Отсутствуют учетные данные для пользователя {username}",
                severity=AuditSeverity.MEDIUM
            )
            return jsonify({'error': 'Username and password are required'}), 400
        
        user = PrivilegedUser.query.filter_by(username=username).first()
        
        if not user:
            log_audit_event(
                AuditEventType.LOGIN_FAILED,
                "Неудачная попытка входа",
                f"Пользователь {username} не найден",
                severity=AuditSeverity.MEDIUM
            )
            return jsonify({'error': 'Invalid credentials'}), 401
        
        if not user.check_password(password):
            user.increment_failed_login()
            db.session.commit()
            
            log_audit_event(
                AuditEventType.LOGIN_FAILED,
                "Неудачная попытка входа",
                f"Неверный пароль для пользователя {username}",
                user_id=user.id,
                severity=AuditSeverity.MEDIUM
            )
            return jsonify({'error': 'Invalid credentials'}), 401
        
        if not user.is_active():
            log_audit_event(
                AuditEventType.LOGIN_FAILED,
                "Попытка входа заблокированного пользователя",
                f"Пользователь {username} заблокирован или неактивен",
                user_id=user.id,
                severity=AuditSeverity.HIGH
            )
            return jsonify({'error': 'Account is inactive or locked'}), 403
        
        if not user.can_access_now():
            log_audit_event(
                AuditEventType.LOGIN_FAILED,
                "Попытка входа вне разрешенного времени",
                f"Пользователь {username} попытался войти вне разрешенного времени",
                user_id=user.id,
                severity=AuditSeverity.MEDIUM
            )
            return jsonify({'error': 'Access not allowed at this time'}), 403
        
        # Успешная аутентификация
        user.reset_failed_login()
        user.last_login = datetime.utcnow()
        db.session.commit()
        
        # Создаем сессию
        session_token = str(uuid.uuid4())
        session['user_id'] = user.id
        session['session_token'] = session_token
        session['username'] = user.username
        
        log_audit_event(
            AuditEventType.LOGIN,
            "Успешный вход в систему",
            f"Пользователь {username} успешно вошел в систему",
            user_id=user.id,
            severity=AuditSeverity.INFO
        )
        
        return jsonify({
            'message': 'Login successful',
            'user': user.to_dict(),
            'session_token': session_token
        }), 200
        
    except Exception as e:
        log_audit_event(
            AuditEventType.LOGIN_FAILED,
            "Ошибка при входе в систему",
            f"Системная ошибка: {str(e)}",
            severity=AuditSeverity.HIGH
        )
        return jsonify({'error': 'Internal server error'}), 500

@auth_bp.route('/logout', methods=['POST'])
def logout():
    """Выход из системы"""
    try:
        user_id = session.get('user_id')
        username = session.get('username')
        
        if user_id:
            log_audit_event(
                AuditEventType.LOGOUT,
                "Выход из системы",
                f"Пользователь {username} вышел из системы",
                user_id=user_id,
                severity=AuditSeverity.INFO
            )
        
        session.clear()
        return jsonify({'message': 'Logout successful'}), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@auth_bp.route('/profile', methods=['GET'])
def get_profile():
    """Получение профиля текущего пользователя"""
    try:
        user_id = session.get('user_id')
        if not user_id:
            return jsonify({'error': 'Not authenticated'}), 401
        
        user = PrivilegedUser.query.get(user_id)
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        return jsonify(user.to_dict()), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@auth_bp.route('/change-password', methods=['POST'])
def change_password():
    """Изменение пароля пользователя"""
    try:
        user_id = session.get('user_id')
        if not user_id:
            return jsonify({'error': 'Not authenticated'}), 401
        
        data = request.get_json()
        current_password = data.get('current_password')
        new_password = data.get('new_password')
        
        if not current_password or not new_password:
            return jsonify({'error': 'Current and new passwords are required'}), 400
        
        user = PrivilegedUser.query.get(user_id)
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        if not user.check_password(current_password):
            log_audit_event(
                AuditEventType.PASSWORD_CHANGE,
                "Неудачная попытка смены пароля",
                f"Неверный текущий пароль для пользователя {user.username}",
                user_id=user.id,
                success=False,
                severity=AuditSeverity.MEDIUM
            )
            return jsonify({'error': 'Current password is incorrect'}), 400
        
        user.set_password(new_password)
        db.session.commit()
        
        log_audit_event(
            AuditEventType.PASSWORD_CHANGE,
            "Успешная смена пароля",
            f"Пользователь {user.username} успешно сменил пароль",
            user_id=user.id,
            severity=AuditSeverity.INFO
        )
        
        return jsonify({'message': 'Password changed successfully'}), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@auth_bp.route('/check-session', methods=['GET'])
def check_session():
    """Проверка активности сессии"""
    try:
        user_id = session.get('user_id')
        session_token = session.get('session_token')
        
        if not user_id or not session_token:
            return jsonify({'authenticated': False}), 200
        
        user = PrivilegedUser.query.get(user_id)
        if not user or not user.is_active():
            session.clear()
            return jsonify({'authenticated': False}), 200
        
        return jsonify({
            'authenticated': True,
            'user': user.to_dict(),
            'session_token': session_token
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

