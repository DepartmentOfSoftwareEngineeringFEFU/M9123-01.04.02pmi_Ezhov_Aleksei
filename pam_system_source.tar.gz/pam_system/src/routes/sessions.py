from flask import Blueprint, request, jsonify, session
from datetime import datetime, timedelta
from src.models.privileged_user import PrivilegedUser, UserRole
from src.models.session import PrivilegedSession, SessionActivity, SessionAlert, SessionStatus, SessionType, db
from src.models.audit import AuditLog, AuditEventType, AuditSeverity
import uuid

sessions_bp = Blueprint('sessions', __name__)

def require_auth():
    """Проверка аутентификации"""
    user_id = session.get('user_id')
    if not user_id:
        return None
    return PrivilegedUser.query.get(user_id)

def log_audit_event(event_type, title, description, user_id=None, session_id=None, success=True, severity=AuditSeverity.INFO):
    """Логирует событие аудита"""
    audit_log = AuditLog(
        event_type=event_type,
        title=title,
        description=description,
        user_id=user_id,
        session_id=session_id,
        success=success,
        severity=severity,
        source_ip=request.remote_addr,
        user_agent=request.headers.get('User-Agent', '')
    )
    db.session.add(audit_log)
    db.session.commit()

@sessions_bp.route('/', methods=['GET'])
def get_sessions():
    """Получение списка сессий"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        status = request.args.get('status', '')
        user_id = request.args.get('user_id', type=int)
        
        query = PrivilegedSession.query
        
        # Обычные пользователи видят только свои сессии
        if current_user.role not in [UserRole.ADMIN, UserRole.AUDITOR]:
            query = query.filter(PrivilegedSession.user_id == current_user.id)
        elif user_id:
            query = query.filter(PrivilegedSession.user_id == user_id)
        
        if status:
            query = query.filter(PrivilegedSession.status == SessionStatus(status))
        
        query = query.order_by(PrivilegedSession.start_time.desc())
        
        sessions_page = query.paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        return jsonify({
            'sessions': [sess.to_dict() for sess in sessions_page.items],
            'total': sessions_page.total,
            'pages': sessions_page.pages,
            'current_page': page
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@sessions_bp.route('/<int:session_id>', methods=['GET'])
def get_session(session_id):
    """Получение информации о сессии"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        session_obj = PrivilegedSession.query.get_or_404(session_id)
        
        # Проверка прав доступа
        if (current_user.role not in [UserRole.ADMIN, UserRole.AUDITOR] and 
            session_obj.user_id != current_user.id):
            return jsonify({'error': 'Insufficient privileges'}), 403
        
        return jsonify(session_obj.to_dict()), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@sessions_bp.route('/', methods=['POST'])
def create_session():
    """Создание новой привилегированной сессии"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        data = request.get_json()
        
        # Проверка обязательных полей
        required_fields = ['target_system', 'target_host', 'session_type']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        # Проверка временных ограничений пользователя
        if not current_user.can_access_now():
            return jsonify({'error': 'Access not allowed at this time'}), 403
        
        # Создание сессии
        session_obj = PrivilegedSession(
            session_token=str(uuid.uuid4()),
            user_id=current_user.id,
            target_system=data['target_system'],
            target_host=data['target_host'],
            target_port=data.get('target_port'),
            session_type=SessionType(data['session_type']),
            max_duration_minutes=data.get('max_duration_minutes', 480),
            idle_timeout_minutes=data.get('idle_timeout_minutes', 30),
            source_ip=request.remote_addr,
            user_agent=request.headers.get('User-Agent', ''),
            justification=data.get('justification', ''),
            recording_enabled=data.get('recording_enabled', True)
        )
        
        db.session.add(session_obj)
        db.session.commit()
        
        log_audit_event(
            AuditEventType.SESSION_START,
            "Начало привилегированной сессии",
            f"Пользователь {current_user.username} начал сессию к {session_obj.target_system}",
            user_id=current_user.id,
            session_id=session_obj.id,
            severity=AuditSeverity.INFO
        )
        
        return jsonify(session_obj.to_dict()), 201
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@sessions_bp.route('/<int:session_id>/terminate', methods=['POST'])
def terminate_session(session_id):
    """Завершение сессии"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        session_obj = PrivilegedSession.query.get_or_404(session_id)
        
        # Проверка прав: пользователь может завершить свою сессию, админы - любую
        if (current_user.role != UserRole.ADMIN and 
            session_obj.user_id != current_user.id):
            return jsonify({'error': 'Insufficient privileges'}), 403
        
        data = request.get_json()
        reason = data.get('reason', 'Manual termination')
        
        session_obj.terminate(reason)
        db.session.commit()
        
        log_audit_event(
            AuditEventType.SESSION_END,
            "Завершение привилегированной сессии",
            f"Сессия {session_obj.session_token} завершена: {reason}",
            user_id=current_user.id,
            session_id=session_obj.id,
            severity=AuditSeverity.INFO
        )
        
        return jsonify({'message': 'Session terminated successfully'}), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@sessions_bp.route('/<int:session_id>/suspend', methods=['POST'])
def suspend_session(session_id):
    """Приостановка сессии"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        # Только админы могут приостанавливать сессии
        if current_user.role != UserRole.ADMIN:
            return jsonify({'error': 'Admin privileges required'}), 403
        
        session_obj = PrivilegedSession.query.get_or_404(session_id)
        data = request.get_json()
        reason = data.get('reason', 'Suspicious activity')
        
        session_obj.suspend(reason)
        db.session.commit()
        
        log_audit_event(
            AuditEventType.SESSION_END,
            "Приостановка привилегированной сессии",
            f"Сессия {session_obj.session_token} приостановлена: {reason}",
            user_id=current_user.id,
            session_id=session_obj.id,
            severity=AuditSeverity.HIGH
        )
        
        return jsonify({'message': 'Session suspended successfully'}), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@sessions_bp.route('/<int:session_id>/activity', methods=['GET'])
def get_session_activity(session_id):
    """Получение активности сессии"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        session_obj = PrivilegedSession.query.get_or_404(session_id)
        
        # Проверка прав доступа
        if (current_user.role not in [UserRole.ADMIN, UserRole.AUDITOR] and 
            session_obj.user_id != current_user.id):
            return jsonify({'error': 'Insufficient privileges'}), 403
        
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 50, type=int)
        
        activities = SessionActivity.query.filter_by(session_id=session_id)\
            .order_by(SessionActivity.timestamp.desc())\
            .paginate(page=page, per_page=per_page, error_out=False)
        
        return jsonify({
            'activities': [activity.to_dict() for activity in activities.items],
            'total': activities.total,
            'pages': activities.pages,
            'current_page': page
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@sessions_bp.route('/<int:session_id>/activity', methods=['POST'])
def log_session_activity(session_id):
    """Логирование активности в сессии"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        session_obj = PrivilegedSession.query.get_or_404(session_id)
        
        # Проверка, что пользователь является владельцем сессии
        if session_obj.user_id != current_user.id:
            return jsonify({'error': 'Not your session'}), 403
        
        data = request.get_json()
        
        activity = SessionActivity(
            session_id=session_id,
            activity_type=data.get('activity_type', 'command'),
            description=data.get('description', ''),
            command=data.get('command', ''),
            file_path=data.get('file_path', ''),
            risk_score=data.get('risk_score', 0)
        )
        
        # Обновляем время последней активности в сессии
        session_obj.update_activity()
        session_obj.commands_logged += 1
        
        db.session.add(activity)
        db.session.commit()
        
        # Проверка на аномальную активность
        if activity.risk_score > 70:
            activity.is_anomalous = True
            
            # Создание алерта
            alert = SessionAlert(
                session_id=session_id,
                alert_type='high_risk_activity',
                severity='high',
                title='Высокорисковая активность',
                description=f'Обнаружена активность с высоким риском: {activity.description}'
            )
            db.session.add(alert)
            db.session.commit()
        
        return jsonify(activity.to_dict()), 201
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@sessions_bp.route('/<int:session_id>/alerts', methods=['GET'])
def get_session_alerts(session_id):
    """Получение алертов сессии"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        session_obj = PrivilegedSession.query.get_or_404(session_id)
        
        # Проверка прав доступа
        if (current_user.role not in [UserRole.ADMIN, UserRole.AUDITOR] and 
            session_obj.user_id != current_user.id):
            return jsonify({'error': 'Insufficient privileges'}), 403
        
        alerts = SessionAlert.query.filter_by(session_id=session_id)\
            .order_by(SessionAlert.triggered_at.desc()).all()
        
        return jsonify([alert.to_dict() for alert in alerts]), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@sessions_bp.route('/alerts/<int:alert_id>/acknowledge', methods=['POST'])
def acknowledge_alert(alert_id):
    """Подтверждение алерта"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        if current_user.role not in [UserRole.ADMIN, UserRole.OPERATOR]:
            return jsonify({'error': 'Insufficient privileges'}), 403
        
        alert = SessionAlert.query.get_or_404(alert_id)
        alert.acknowledge(current_user.id)
        db.session.commit()
        
        return jsonify({'message': 'Alert acknowledged successfully'}), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@sessions_bp.route('/active', methods=['GET'])
def get_active_sessions():
    """Получение активных сессий"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        query = PrivilegedSession.query.filter_by(status=SessionStatus.ACTIVE)
        
        # Обычные пользователи видят только свои сессии
        if current_user.role not in [UserRole.ADMIN, UserRole.AUDITOR]:
            query = query.filter(PrivilegedSession.user_id == current_user.id)
        
        active_sessions = query.order_by(PrivilegedSession.start_time.desc()).all()
        
        # Проверяем и обновляем статус истекших сессий
        for sess in active_sessions:
            if sess.is_expired():
                sess.status = SessionStatus.EXPIRED
                sess.end_time = datetime.utcnow()
        
        db.session.commit()
        
        # Возвращаем только действительно активные сессии
        active_sessions = [sess for sess in active_sessions if sess.status == SessionStatus.ACTIVE]
        
        return jsonify([sess.to_dict() for sess in active_sessions]), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

