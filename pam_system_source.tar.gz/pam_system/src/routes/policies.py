from flask import Blueprint, request, jsonify, session
from datetime import datetime, time
from src.models.privileged_user import PrivilegedUser, UserRole
from src.models.policy import AccessPolicy, PolicyViolation, ApprovalRequest, PolicyType, PolicyStatus, PolicyAction, db
from src.models.audit import AuditLog, AuditEventType, AuditSeverity

policies_bp = Blueprint('policies', __name__)

def require_auth():
    """Проверка аутентификации"""
    user_id = session.get('user_id')
    if not user_id:
        return None
    return PrivilegedUser.query.get(user_id)

def log_audit_event(event_type, title, description, user_id=None, success=True, severity=AuditSeverity.INFO):
    """Логирует событие аудита"""
    audit_log = AuditLog(
        event_type=event_type,
        title=title,
        description=description,
        user_id=user_id,
        success=success,
        severity=severity,
        source_ip=request.remote_addr,
        user_agent=request.headers.get('User-Agent', '')
    )
    db.session.add(audit_log)
    db.session.commit()

@policies_bp.route('/', methods=['GET'])
def get_policies():
    """Получение списка политик доступа"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        if current_user.role not in [UserRole.ADMIN, UserRole.AUDITOR]:
            return jsonify({'error': 'Insufficient privileges'}), 403
        
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        policy_type = request.args.get('type', '')
        status = request.args.get('status', '')
        
        query = AccessPolicy.query
        
        if policy_type:
            query = query.filter(AccessPolicy.policy_type == PolicyType(policy_type))
        
        if status:
            query = query.filter(AccessPolicy.status == PolicyStatus(status))
        
        query = query.order_by(AccessPolicy.priority.asc(), AccessPolicy.name.asc())
        
        policies = query.paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        return jsonify({
            'policies': [policy.to_dict() for policy in policies.items],
            'total': policies.total,
            'pages': policies.pages,
            'current_page': page
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@policies_bp.route('/<int:policy_id>', methods=['GET'])
def get_policy(policy_id):
    """Получение информации о политике"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        if current_user.role not in [UserRole.ADMIN, UserRole.AUDITOR]:
            return jsonify({'error': 'Insufficient privileges'}), 403
        
        policy = AccessPolicy.query.get_or_404(policy_id)
        return jsonify(policy.to_dict()), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@policies_bp.route('/', methods=['POST'])
def create_policy():
    """Создание новой политики доступа"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        if current_user.role != UserRole.ADMIN:
            return jsonify({'error': 'Admin privileges required'}), 403
        
        data = request.get_json()
        
        # Проверка обязательных полей
        required_fields = ['name', 'policy_type', 'action']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        # Проверка уникальности имени
        if AccessPolicy.query.filter_by(name=data['name']).first():
            return jsonify({'error': 'Policy name already exists'}), 400
        
        # Создание политики
        policy = AccessPolicy(
            name=data['name'],
            description=data.get('description'),
            policy_type=PolicyType(data['policy_type']),
            status=PolicyStatus(data.get('status', 'active')),
            priority=data.get('priority', 100),
            action=PolicyAction(data['action']),
            created_by=current_user.id
        )
        
        # Установка условий
        if data.get('conditions'):
            policy.set_conditions(data['conditions'])
        
        # Установка временных ограничений
        if data.get('time_start'):
            policy.time_start = datetime.strptime(data['time_start'], '%H:%M').time()
        if data.get('time_end'):
            policy.time_end = datetime.strptime(data['time_end'], '%H:%M').time()
        if data.get('days_of_week'):
            policy.days_of_week = data['days_of_week']
        
        db.session.add(policy)
        db.session.commit()
        
        log_audit_event(
            AuditEventType.SYSTEM_CONFIGURATION,
            "Создана новая политика доступа",
            f"Администратор {current_user.username} создал политику {policy.name}",
            user_id=current_user.id,
            severity=AuditSeverity.INFO
        )
        
        return jsonify(policy.to_dict()), 201
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@policies_bp.route('/<int:policy_id>', methods=['PUT'])
def update_policy(policy_id):
    """Обновление политики доступа"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        if current_user.role != UserRole.ADMIN:
            return jsonify({'error': 'Admin privileges required'}), 403
        
        policy = AccessPolicy.query.get_or_404(policy_id)
        data = request.get_json()
        
        # Обновление полей
        if 'name' in data:
            # Проверка уникальности имени
            existing = AccessPolicy.query.filter_by(name=data['name']).first()
            if existing and existing.id != policy_id:
                return jsonify({'error': 'Policy name already exists'}), 400
            policy.name = data['name']
        
        if 'description' in data:
            policy.description = data['description']
        if 'status' in data:
            policy.status = PolicyStatus(data['status'])
        if 'priority' in data:
            policy.priority = data['priority']
        if 'action' in data:
            policy.action = PolicyAction(data['action'])
        
        # Обновление условий
        if 'conditions' in data:
            policy.set_conditions(data['conditions'])
        
        # Обновление временных ограничений
        if 'time_start' in data:
            policy.time_start = datetime.strptime(data['time_start'], '%H:%M').time() if data['time_start'] else None
        if 'time_end' in data:
            policy.time_end = datetime.strptime(data['time_end'], '%H:%M').time() if data['time_end'] else None
        if 'days_of_week' in data:
            policy.days_of_week = data['days_of_week']
        
        policy.updated_at = datetime.utcnow()
        db.session.commit()
        
        log_audit_event(
            AuditEventType.SYSTEM_CONFIGURATION,
            "Обновлена политика доступа",
            f"Администратор {current_user.username} обновил политику {policy.name}",
            user_id=current_user.id,
            severity=AuditSeverity.INFO
        )
        
        return jsonify(policy.to_dict()), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@policies_bp.route('/<int:policy_id>', methods=['DELETE'])
def delete_policy(policy_id):
    """Удаление политики доступа"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        if current_user.role != UserRole.ADMIN:
            return jsonify({'error': 'Admin privileges required'}), 403
        
        policy = AccessPolicy.query.get_or_404(policy_id)
        policy_name = policy.name
        
        db.session.delete(policy)
        db.session.commit()
        
        log_audit_event(
            AuditEventType.SYSTEM_CONFIGURATION,
            "Удалена политика доступа",
            f"Администратор {current_user.username} удалил политику {policy_name}",
            user_id=current_user.id,
            severity=AuditSeverity.MEDIUM
        )
        
        return jsonify({'message': 'Policy deleted successfully'}), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@policies_bp.route('/violations', methods=['GET'])
def get_policy_violations():
    """Получение нарушений политик"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        if current_user.role not in [UserRole.ADMIN, UserRole.AUDITOR]:
            return jsonify({'error': 'Insufficient privileges'}), 403
        
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        severity = request.args.get('severity', '')
        acknowledged = request.args.get('acknowledged', '')
        
        query = PolicyViolation.query
        
        if severity:
            query = query.filter(PolicyViolation.severity == severity)
        
        if acknowledged == 'true':
            query = query.filter(PolicyViolation.acknowledged == True)
        elif acknowledged == 'false':
            query = query.filter(PolicyViolation.acknowledged == False)
        
        query = query.order_by(PolicyViolation.violation_time.desc())
        
        violations = query.paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        return jsonify({
            'violations': [violation.to_dict() for violation in violations.items],
            'total': violations.total,
            'pages': violations.pages,
            'current_page': page
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@policies_bp.route('/violations/<int:violation_id>/acknowledge', methods=['POST'])
def acknowledge_violation(violation_id):
    """Подтверждение обработки нарушения политики"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        if current_user.role not in [UserRole.ADMIN, UserRole.OPERATOR]:
            return jsonify({'error': 'Insufficient privileges'}), 403
        
        violation = PolicyViolation.query.get_or_404(violation_id)
        data = request.get_json()
        
        notes = data.get('notes', '')
        violation.acknowledge(current_user.id, notes)
        db.session.commit()
        
        return jsonify({'message': 'Violation acknowledged successfully'}), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@policies_bp.route('/approval-requests', methods=['GET'])
def get_approval_requests():
    """Получение запросов на утверждение"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        status = request.args.get('status', '')
        
        query = ApprovalRequest.query
        
        # Обычные пользователи видят только свои запросы
        if current_user.role not in [UserRole.ADMIN, UserRole.OPERATOR]:
            query = query.filter(ApprovalRequest.requester_id == current_user.id)
        
        if status:
            query = query.filter(ApprovalRequest.status == status)
        
        query = query.order_by(ApprovalRequest.created_at.desc())
        
        requests = query.paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        return jsonify({
            'requests': [req.to_dict() for req in requests.items],
            'total': requests.total,
            'pages': requests.pages,
            'current_page': page
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@policies_bp.route('/approval-requests', methods=['POST'])
def create_approval_request():
    """Создание запроса на утверждение"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        data = request.get_json()
        
        # Проверка обязательных полей
        required_fields = ['request_type', 'justification']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        # Создание запроса
        approval_request = ApprovalRequest(
            requester_id=current_user.id,
            request_type=data['request_type'],
            target_system=data.get('target_system'),
            target_resource=data.get('target_resource'),
            justification=data['justification'],
            duration_minutes=data.get('duration_minutes')
        )
        
        # Установка временных рамок
        if data.get('requested_start'):
            approval_request.requested_start = datetime.fromisoformat(data['requested_start'].replace('Z', '+00:00'))
        if data.get('requested_end'):
            approval_request.requested_end = datetime.fromisoformat(data['requested_end'].replace('Z', '+00:00'))
        
        db.session.add(approval_request)
        db.session.commit()
        
        log_audit_event(
            AuditEventType.SYSTEM_CONFIGURATION,
            "Создан запрос на утверждение",
            f"Пользователь {current_user.username} создал запрос на {approval_request.request_type}",
            user_id=current_user.id,
            severity=AuditSeverity.INFO
        )
        
        return jsonify(approval_request.to_dict()), 201
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@policies_bp.route('/approval-requests/<int:request_id>/approve', methods=['POST'])
def approve_request(request_id):
    """Утверждение запроса"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        if current_user.role not in [UserRole.ADMIN, UserRole.OPERATOR]:
            return jsonify({'error': 'Insufficient privileges'}), 403
        
        approval_request = ApprovalRequest.query.get_or_404(request_id)
        data = request.get_json()
        
        notes = data.get('notes', '')
        approval_request.approve(current_user.id, notes)
        db.session.commit()
        
        log_audit_event(
            AuditEventType.SYSTEM_CONFIGURATION,
            "Утвержден запрос",
            f"Пользователь {current_user.username} утвердил запрос #{request_id}",
            user_id=current_user.id,
            severity=AuditSeverity.INFO
        )
        
        return jsonify({'message': 'Request approved successfully'}), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@policies_bp.route('/approval-requests/<int:request_id>/reject', methods=['POST'])
def reject_request(request_id):
    """Отклонение запроса"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        if current_user.role not in [UserRole.ADMIN, UserRole.OPERATOR]:
            return jsonify({'error': 'Insufficient privileges'}), 403
        
        approval_request = ApprovalRequest.query.get_or_404(request_id)
        data = request.get_json()
        
        notes = data.get('notes', '')
        approval_request.reject(current_user.id, notes)
        db.session.commit()
        
        log_audit_event(
            AuditEventType.SYSTEM_CONFIGURATION,
            "Отклонен запрос",
            f"Пользователь {current_user.username} отклонил запрос #{request_id}",
            user_id=current_user.id,
            severity=AuditSeverity.INFO
        )
        
        return jsonify({'message': 'Request rejected successfully'}), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@policies_bp.route('/evaluate', methods=['POST'])
def evaluate_policies():
    """Оценка политик для данного контекста"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        data = request.get_json()
        context = {
            'user_id': current_user.id,
            'user_role': current_user.role.value,
            'source_ip': request.remote_addr,
            'target_system': data.get('target_system'),
            'command': data.get('command')
        }
        
        # Получение активных политик, отсортированных по приоритету
        active_policies = AccessPolicy.query.filter_by(status=PolicyStatus.ACTIVE)\
            .order_by(AccessPolicy.priority.asc()).all()
        
        results = []
        for policy in active_policies:
            if policy.is_applicable_now():
                evaluation_result = policy.evaluate_conditions(context)
                results.append({
                    'policy_id': policy.id,
                    'policy_name': policy.name,
                    'policy_type': policy.policy_type.value,
                    'action': policy.action.value,
                    'applicable': evaluation_result,
                    'priority': policy.priority
                })
        
        return jsonify({'policy_evaluations': results}), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

