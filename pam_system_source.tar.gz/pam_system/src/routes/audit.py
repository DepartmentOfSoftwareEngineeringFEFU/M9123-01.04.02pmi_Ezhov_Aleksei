from flask import Blueprint, request, jsonify, session
from datetime import datetime, timedelta
from src.models.privileged_user import PrivilegedUser, UserRole
from src.models.audit import AuditLog, ComplianceReport, AnomalyDetection, AuditEventType, AuditSeverity, db
from sqlalchemy import func, and_
import json

audit_bp = Blueprint('audit', __name__)

def require_auth():
    """Проверка аутентификации"""
    user_id = session.get('user_id')
    if not user_id:
        return None
    return PrivilegedUser.query.get(user_id)

@audit_bp.route('/logs', methods=['GET'])
def get_audit_logs():
    """Получение журнала аудита"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        # Только админы и аудиторы могут просматривать логи
        if current_user.role not in [UserRole.ADMIN, UserRole.AUDITOR]:
            return jsonify({'error': 'Insufficient privileges'}), 403
        
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 50, type=int)
        event_type = request.args.get('event_type', '')
        severity = request.args.get('severity', '')
        user_id = request.args.get('user_id', type=int)
        start_date = request.args.get('start_date', '')
        end_date = request.args.get('end_date', '')
        search = request.args.get('search', '')
        
        query = AuditLog.query
        
        # Фильтры
        if event_type:
            query = query.filter(AuditLog.event_type == AuditEventType(event_type))
        
        if severity:
            query = query.filter(AuditLog.severity == AuditSeverity(severity))
        
        if user_id:
            query = query.filter(AuditLog.user_id == user_id)
        
        if start_date:
            start_dt = datetime.fromisoformat(start_date.replace('Z', '+00:00'))
            query = query.filter(AuditLog.timestamp >= start_dt)
        
        if end_date:
            end_dt = datetime.fromisoformat(end_date.replace('Z', '+00:00'))
            query = query.filter(AuditLog.timestamp <= end_dt)
        
        if search:
            query = query.filter(
                (AuditLog.title.contains(search)) |
                (AuditLog.description.contains(search))
            )
        
        query = query.order_by(AuditLog.timestamp.desc())
        
        logs = query.paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        return jsonify({
            'logs': [log.to_dict() for log in logs.items],
            'total': logs.total,
            'pages': logs.pages,
            'current_page': page
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@audit_bp.route('/logs/<int:log_id>', methods=['GET'])
def get_audit_log(log_id):
    """Получение детальной информации о событии аудита"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        if current_user.role not in [UserRole.ADMIN, UserRole.AUDITOR]:
            return jsonify({'error': 'Insufficient privileges'}), 403
        
        log = AuditLog.query.get_or_404(log_id)
        return jsonify(log.to_dict()), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@audit_bp.route('/statistics', methods=['GET'])
def get_audit_statistics():
    """Получение статистики аудита"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        if current_user.role not in [UserRole.ADMIN, UserRole.AUDITOR]:
            return jsonify({'error': 'Insufficient privileges'}), 403
        
        # Период для статистики (по умолчанию последние 30 дней)
        days = request.args.get('days', 30, type=int)
        start_date = datetime.utcnow() - timedelta(days=days)
        
        # Общая статистика
        total_events = AuditLog.query.filter(AuditLog.timestamp >= start_date).count()
        security_events = AuditLog.query.filter(
            AuditLog.timestamp >= start_date,
            AuditLog.severity.in_([AuditSeverity.HIGH, AuditSeverity.CRITICAL])
        ).count()
        
        failed_logins = AuditLog.query.filter(
            AuditLog.timestamp >= start_date,
            AuditLog.event_type == AuditEventType.LOGIN_FAILED
        ).count()
        
        # Статистика по типам событий
        event_stats = db.session.query(
            AuditLog.event_type,
            func.count(AuditLog.id).label('count')
        ).filter(
            AuditLog.timestamp >= start_date
        ).group_by(AuditLog.event_type).all()
        
        # Статистика по уровням серьезности
        severity_stats = db.session.query(
            AuditLog.severity,
            func.count(AuditLog.id).label('count')
        ).filter(
            AuditLog.timestamp >= start_date
        ).group_by(AuditLog.severity).all()
        
        # Статистика по пользователям
        user_stats = db.session.query(
            AuditLog.user_id,
            func.count(AuditLog.id).label('count')
        ).filter(
            AuditLog.timestamp >= start_date,
            AuditLog.user_id.isnot(None)
        ).group_by(AuditLog.user_id).order_by(func.count(AuditLog.id).desc()).limit(10).all()
        
        # Временная статистика (по дням)
        daily_stats = db.session.query(
            func.date(AuditLog.timestamp).label('date'),
            func.count(AuditLog.id).label('count')
        ).filter(
            AuditLog.timestamp >= start_date
        ).group_by(func.date(AuditLog.timestamp)).order_by(func.date(AuditLog.timestamp)).all()
        
        return jsonify({
            'period_days': days,
            'total_events': total_events,
            'security_events': security_events,
            'failed_logins': failed_logins,
            'event_types': [{'type': stat[0].value, 'count': stat[1]} for stat in event_stats],
            'severity_levels': [{'severity': stat[0].value, 'count': stat[1]} for stat in severity_stats],
            'top_users': [{'user_id': stat[0], 'count': stat[1]} for stat in user_stats],
            'daily_activity': [{'date': stat[0].isoformat(), 'count': stat[1]} for stat in daily_stats]
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@audit_bp.route('/reports', methods=['GET'])
def get_compliance_reports():
    """Получение списка отчетов соответствия"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        if current_user.role not in [UserRole.ADMIN, UserRole.AUDITOR]:
            return jsonify({'error': 'Insufficient privileges'}), 403
        
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        
        reports = ComplianceReport.query.order_by(ComplianceReport.generated_at.desc())\
            .paginate(page=page, per_page=per_page, error_out=False)
        
        return jsonify({
            'reports': [report.to_dict() for report in reports.items],
            'total': reports.total,
            'pages': reports.pages,
            'current_page': page
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@audit_bp.route('/reports', methods=['POST'])
def generate_compliance_report():
    """Генерация отчета соответствия"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        if current_user.role not in [UserRole.ADMIN, UserRole.AUDITOR]:
            return jsonify({'error': 'Insufficient privileges'}), 403
        
        data = request.get_json()
        
        # Проверка обязательных полей
        required_fields = ['report_name', 'period_start', 'period_end']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        period_start = datetime.fromisoformat(data['period_start'].replace('Z', '+00:00'))
        period_end = datetime.fromisoformat(data['period_end'].replace('Z', '+00:00'))
        
        # Сбор статистики для отчета
        total_events = AuditLog.query.filter(
            and_(AuditLog.timestamp >= period_start, AuditLog.timestamp <= period_end)
        ).count()
        
        security_events = AuditLog.query.filter(
            and_(
                AuditLog.timestamp >= period_start,
                AuditLog.timestamp <= period_end,
                AuditLog.severity.in_([AuditSeverity.HIGH, AuditSeverity.CRITICAL])
            )
        ).count()
        
        failed_access_attempts = AuditLog.query.filter(
            and_(
                AuditLog.timestamp >= period_start,
                AuditLog.timestamp <= period_end,
                AuditLog.event_type.in_([
                    AuditEventType.LOGIN_FAILED,
                    AuditEventType.POLICY_VIOLATION
                ])
            )
        ).count()
        
        # Создание отчета
        report = ComplianceReport(
            report_name=data['report_name'],
            report_type=data.get('report_type', 'custom'),
            compliance_standard=data.get('compliance_standard', ''),
            period_start=period_start,
            period_end=period_end,
            generated_by=current_user.id,
            total_events=total_events,
            security_events=security_events,
            failed_access_attempts=failed_access_attempts,
            summary=f"Отчет за период с {period_start.date()} по {period_end.date()}",
            recommendations="Рекомендуется регулярный мониторинг событий безопасности"
        )
        
        db.session.add(report)
        db.session.commit()
        
        return jsonify(report.to_dict()), 201
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@audit_bp.route('/anomalies', methods=['GET'])
def get_anomalies():
    """Получение обнаруженных аномалий"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        if current_user.role not in [UserRole.ADMIN, UserRole.AUDITOR]:
            return jsonify({'error': 'Insufficient privileges'}), 403
        
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        status = request.args.get('status', '')
        anomaly_type = request.args.get('type', '')
        
        query = AnomalyDetection.query
        
        if status:
            query = query.filter(AnomalyDetection.status == status)
        
        if anomaly_type:
            query = query.filter(AnomalyDetection.anomaly_type == anomaly_type)
        
        query = query.order_by(AnomalyDetection.detected_at.desc())
        
        anomalies = query.paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        return jsonify({
            'anomalies': [anomaly.to_dict() for anomaly in anomalies.items],
            'total': anomalies.total,
            'pages': anomalies.pages,
            'current_page': page
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@audit_bp.route('/anomalies/<int:anomaly_id>/resolve', methods=['POST'])
def resolve_anomaly(anomaly_id):
    """Разрешение аномалии"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        if current_user.role not in [UserRole.ADMIN, UserRole.OPERATOR]:
            return jsonify({'error': 'Insufficient privileges'}), 403
        
        anomaly = AnomalyDetection.query.get_or_404(anomaly_id)
        data = request.get_json()
        
        notes = data.get('notes', '')
        is_false_positive = data.get('is_false_positive', False)
        
        if is_false_positive:
            anomaly.mark_as_false_positive(current_user.id, notes)
        else:
            anomaly.mark_as_resolved(current_user.id, notes)
        
        db.session.commit()
        
        return jsonify({'message': 'Anomaly resolved successfully'}), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

@audit_bp.route('/search', methods=['POST'])
def search_audit_logs():
    """Расширенный поиск в журнале аудита"""
    try:
        current_user = require_auth()
        if not current_user:
            return jsonify({'error': 'Authentication required'}), 401
        
        if current_user.role not in [UserRole.ADMIN, UserRole.AUDITOR]:
            return jsonify({'error': 'Insufficient privileges'}), 403
        
        data = request.get_json()
        
        query = AuditLog.query
        
        # Применение фильтров поиска
        if data.get('event_types'):
            event_types = [AuditEventType(et) for et in data['event_types']]
            query = query.filter(AuditLog.event_type.in_(event_types))
        
        if data.get('severity_levels'):
            severity_levels = [AuditSeverity(sl) for sl in data['severity_levels']]
            query = query.filter(AuditLog.severity.in_(severity_levels))
        
        if data.get('user_ids'):
            query = query.filter(AuditLog.user_id.in_(data['user_ids']))
        
        if data.get('source_ips'):
            query = query.filter(AuditLog.source_ip.in_(data['source_ips']))
        
        if data.get('start_date'):
            start_dt = datetime.fromisoformat(data['start_date'].replace('Z', '+00:00'))
            query = query.filter(AuditLog.timestamp >= start_dt)
        
        if data.get('end_date'):
            end_dt = datetime.fromisoformat(data['end_date'].replace('Z', '+00:00'))
            query = query.filter(AuditLog.timestamp <= end_dt)
        
        if data.get('text_search'):
            search_text = data['text_search']
            query = query.filter(
                (AuditLog.title.contains(search_text)) |
                (AuditLog.description.contains(search_text)) |
                (AuditLog.target_system.contains(search_text))
            )
        
        # Сортировка
        if data.get('sort_by') == 'timestamp_asc':
            query = query.order_by(AuditLog.timestamp.asc())
        else:
            query = query.order_by(AuditLog.timestamp.desc())
        
        # Пагинация
        page = data.get('page', 1)
        per_page = data.get('per_page', 50)
        
        results = query.paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        return jsonify({
            'logs': [log.to_dict() for log in results.items],
            'total': results.total,
            'pages': results.pages,
            'current_page': page
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Internal server error'}), 500

